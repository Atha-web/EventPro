package com.example.finalapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class AdminSPProductActivity extends AppCompatActivity {

    private ArrayList<productClass2> ProductModelArrayList;
    private DBHandler dbHandler;
    private AdminSPPRowViewHolder ProductRvAdapter;
    private RecyclerView SearchProductRV;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_spproduct);


        ProductModelArrayList = new ArrayList<>();
        dbHandler = new DBHandler(AdminSPProductActivity.this);

        String Id = getIntent().getStringExtra("Id");
        ProductModelArrayList = dbHandler.SearchProduct3(Id);

        ProductRvAdapter = new AdminSPPRowViewHolder(ProductModelArrayList, AdminSPProductActivity.this);
        SearchProductRV = findViewById(R.id.spp_rv);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(AdminSPProductActivity.this, RecyclerView.VERTICAL, false);
        SearchProductRV.setLayoutManager(linearLayoutManager);

        SearchProductRV.setAdapter(ProductRvAdapter);

        if (ProductModelArrayList.size() != 0) {

            Toast.makeText(AdminSPProductActivity.this, "Product  Found", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(AdminSPProductActivity.this, "Product Not Found", Toast.LENGTH_SHORT).show();

             }







    }
}