package com.example.finalapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;

public class S_P_ProviderHomeAvtivtiy extends AppCompatActivity {




    DrawerLayout drawerLayout;
    LinearLayout s_search,s_home,s_logout;
    ImageView menu;
    String spid;
    AlertDialog.Builder builder;



    private ArrayList<ProductClass> ProductModelArrayList;
    private DBHandler dbHandler;
    private S_ProductRowViewHolderUpdate ProductRvAdapter;
    private RecyclerView SearchProductRV;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sprovider_home_avtivtiy);


        drawerLayout=findViewById(R.id.drawerLayout);
        menu=findViewById(R.id.menu);
        s_search=findViewById(R.id.s_searchpage);
        s_home=findViewById(R.id.s_p_homepage);
        s_logout=findViewById(R.id.s_p_logoutpage);
        builder = new AlertDialog.Builder(this);




        spid = getIntent().getStringExtra("SPID");

        ProductModelArrayList = new ArrayList<>();
        dbHandler = new DBHandler(S_P_ProviderHomeAvtivtiy.this);


        ProductModelArrayList = dbHandler.UpdateSearchProduct(spid);

        ProductRvAdapter = new S_ProductRowViewHolderUpdate(ProductModelArrayList, S_P_ProviderHomeAvtivtiy.this);
        SearchProductRV = findViewById(R.id.s_pro_rv);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(S_P_ProviderHomeAvtivtiy.this, RecyclerView.VERTICAL, false);
        SearchProductRV.setLayoutManager(linearLayoutManager);

        SearchProductRV.setAdapter(ProductRvAdapter);

        if (ProductModelArrayList.size() != 0) {

            Toast.makeText(S_P_ProviderHomeAvtivtiy.this, "Product  Found", Toast.LENGTH_SHORT).show();

        }
        else {
            Toast.makeText(S_P_ProviderHomeAvtivtiy.this, "Product Not Found", Toast.LENGTH_SHORT).show();

             }






        s_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                builder.setTitle(" App Logout ")
                        .setMessage(" Do you want to Logout this App ")
                        .setIcon(R.drawable.baseline_logout_24)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                redirectActivity(S_P_ProviderHomeAvtivtiy.this, LoginActivity.class);

                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        }).show();

            }
        });







        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opendrawer(drawerLayout);
            }
        });

        s_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recreate();
            }
        });

        s_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(S_P_ProviderHomeAvtivtiy.this,S_P_CategoryProductActivity.class);
                intent.putExtra("SPID",spid);
                startActivity(intent);
                //redirectActivity(S_ProviderHomeAvtivtiy.this, S_P_AddProductAvtivity.class);
            }
        });



    }



    public static void opendrawer(DrawerLayout drawerLayout){

        drawerLayout.openDrawer(GravityCompat.START);
    }

    public static void closedrawer(DrawerLayout drawerLayout) {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    public static void redirectActivity(Activity activity, Class SecondActivity){

        Intent intent = new Intent(activity,SecondActivity);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
        activity.finish();

    }

    @Override
    protected void onPause() {
        super.onPause();
        closedrawer(drawerLayout);
    }



}