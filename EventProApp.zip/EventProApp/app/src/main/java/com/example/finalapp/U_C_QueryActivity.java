package com.example.finalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class U_C_QueryActivity extends AppCompatActivity {


    private EditText Q_spid,Q_userid,Q_text;
    private Button Q_Button,back;
    String query_spid,query_userid,query_text;
    AlertDialog.Builder builder;
    private DBHandler dbHandler ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uc_query);


        String USID = getIntent().getStringExtra("USID");



        dbHandler = new DBHandler(U_C_QueryActivity.this);


        Q_spid=findViewById(R.id.queryspid);
        Q_userid=findViewById(R.id.queryuserid);
        Q_text=findViewById(R.id.querytext);
        Q_Button=findViewById(R.id.buttonquery);
        back=findViewById(R.id.buttonback4);
        builder = new AlertDialog.Builder(this);

        Q_userid.setText(USID);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(U_C_QueryActivity.this, U_C_UserHomeActivity.class);
                i.putExtra("USID",USID);
                startActivity(i);
            }
        });

        Q_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                query_spid=Q_spid.getText().toString();
                query_userid=Q_userid.getText().toString();
                query_text=Q_text.getText().toString();

                if(Q_spid.getText().toString().isEmpty()||Q_userid.getText().toString().isEmpty()
                        ||Q_text.getText().toString().isEmpty()){
                    Toast.makeText(U_C_QueryActivity.this, "Feild Cant be blank !!!", Toast.LENGTH_SHORT).show();
                }
                else {

                    if (dbHandler.addQuery( query_userid,query_spid, query_text)) {

                        builder.setTitle(" Query Form ...")
                                .setMessage("New User Query Added Succesfully... ")
                                .setIcon(R.drawable.baseline_add_task_24)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int i) {
                                        dialog.cancel();
                                    }
                                }).show();
                        Toast.makeText(U_C_QueryActivity.this, "Query Sended", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(U_C_QueryActivity.this, "Query Not Sended", Toast.LENGTH_SHORT).show();

                    }
                }

            }
        });
























        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_Navigation1);

        bottomNavigationView.setSelectedItemId(R.id.Query1);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                if(menuItem.getItemId()== R.id.View1){
                    Intent intent = new Intent(U_C_QueryActivity.this,U_C_ViewQueryActivity.class);
                    intent.putExtra("USID",USID);
                    startActivity(intent);
                    overridePendingTransition(0,0);

                } else if (menuItem.getItemId()== R.id.Search1) {
                    Intent intent = new Intent(U_C_QueryActivity.this, U_C_ProductSearchActivity.class);
                    intent.putExtra("USID",USID);
                    startActivity(intent);

                    overridePendingTransition(0,0);
                } else if (menuItem.getItemId()== R.id.Query1) {

                    return  true;
                }
                else if (menuItem.getItemId()== R.id.Order1) {

                    Intent intent = new Intent(U_C_QueryActivity.this,U_C_OrderViewActivity.class);
                    intent.putExtra("USID",USID);
                    startActivity(intent);

                    overridePendingTransition(0,0);

                }
                return false;
            }
        });

    }
}