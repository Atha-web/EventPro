package com.example.finalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class U_C_ProductSearchActivity extends AppCompatActivity {


    EditText Search_productname;
    Button search_button,search_all_button;

    private ArrayList<ProductClass> ProductModelArrayList;
    private DBHandler dbHandler;
    private S_ProductRowViewHolder ProductRvAdapter;
    private RecyclerView SearchProductRV;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uc_product_search);


        String USID = getIntent().getStringExtra("USID");

        Search_productname=findViewById(R.id.s_search_product);
        search_button=findViewById(R.id.s_button_product);
        search_all_button=findViewById(R.id.s_button_allproduct);

        search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(Search_productname.getText().toString().isEmpty()){

                    Toast.makeText(U_C_ProductSearchActivity.this, "Feild cant be blank!!!!", Toast.LENGTH_SHORT).show();

                }
                else {


                    ProductModelArrayList = new ArrayList<>();
                    dbHandler = new DBHandler(U_C_ProductSearchActivity.this);

                    String SearchProduct = Search_productname.getText().toString();
                    ProductModelArrayList = dbHandler.SearchProduct2(SearchProduct);

                    ProductRvAdapter = new S_ProductRowViewHolder(ProductModelArrayList, U_C_ProductSearchActivity.this);
                    SearchProductRV = findViewById(R.id.s_pro_rv04);

                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(U_C_ProductSearchActivity.this, RecyclerView.VERTICAL, false);
                    SearchProductRV.setLayoutManager(linearLayoutManager);

                    SearchProductRV.setAdapter(ProductRvAdapter);

                    if (ProductModelArrayList.size() != 0) {

                        Toast.makeText(U_C_ProductSearchActivity.this, "Product  Found", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(U_C_ProductSearchActivity.this, "Product Not Found", Toast.LENGTH_SHORT).show();
                        Toast.makeText(U_C_ProductSearchActivity.this, "Please Check correct Prodcut Name", Toast.LENGTH_SHORT).show();
                    }


                }



            }
        });

        search_all_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(U_C_ProductSearchActivity.this,S_ViewAllProductActivity.class);
                startActivity(intent);


            }
        });














        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_Navigation1);

        bottomNavigationView.setSelectedItemId(R.id.Search1);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                if(menuItem.getItemId()== R.id.View1){
                    Intent intent = new Intent(U_C_ProductSearchActivity.this,U_C_ViewQueryActivity.class);
                    intent.putExtra("USID",USID);
                    startActivity(intent);
                    overridePendingTransition(0,0);

                } else if (menuItem.getItemId()== R.id.Search1) {
                    return  true;
                } else if (menuItem.getItemId()== R.id.Query1) {
                    Intent intent = new Intent(U_C_ProductSearchActivity.this, U_C_QueryActivity.class);
                    intent.putExtra("USID",USID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                }
                else if (menuItem.getItemId()== R.id.Order1) {

                    Intent intent = new Intent(U_C_ProductSearchActivity.this,U_C_OrderViewActivity.class);
                    intent.putExtra("USID",USID);
                    startActivity(intent);

                    overridePendingTransition(0,0);

                }
                return false;
            }
        });

    }
}