package com.example.finalapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class S_OrderRowViewHolder extends RecyclerView.Adapter<S_OrderRowViewHolder.ViewHolder> {
    private ArrayList<OrderClass> OrderModalArrayList;
    private Context context;
    AlertDialog.Builder builder;
    DBHandler dbHandler;


    public S_OrderRowViewHolder(ArrayList<OrderClass> orderModalArrayList, Context context) {
        OrderModalArrayList = orderModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public S_OrderRowViewHolder.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_row2, parent, false);
        return new S_OrderRowViewHolder.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull S_OrderRowViewHolder.ViewHolder holder, int position) {

        OrderClass modal = OrderModalArrayList.get(position);//link adater to class
        byte[] image = modal.getProavatar();
        Bitmap bitmap = BitmapFactory.decodeByteArray(image,0,image.length);



        holder.OrderID.setText(modal.getOrderid());
        holder.OrderuserID.setText("User ID : "+modal.getOrderUSid());
        holder.OrderSPID.setText(modal.getOrderSPid());
        holder.OrderPNAME.setText(modal.getOrderproductname());
        holder.OrderCNAME.setText(modal.getOrdercategoryname());
        holder.OrderPNUMBER.setText("User Contact : "+modal.getOrderusernumber());
        holder.OrderQTY.setText("Product QTY : "+modal.getOrderproducteqty());
        holder.OrderLocation.setText("User Location : "+modal.getOrderuserlocation());
        holder.OrderImage.setImageBitmap(bitmap);


        holder.Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                dbHandler = new DBHandler(context);

                String message="Order has been Confirmed";
                String sid=modal.getOrderSPid();
                String uid=modal.getOrderUSid();
                String oid=modal.getOrderid();
                dbHandler.addConfirm(sid,oid,uid,message);

                Toast.makeText(context, "Order has been Confirmed", Toast.LENGTH_SHORT).show();


            }
        });

        holder.Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                dbHandler = new DBHandler(context);

                String message="Order has been Canceled";
                String sid=modal.getOrderSPid();
                String uid=modal.getOrderUSid();
                String oid=modal.getOrderid();

                dbHandler.addConfirm(sid,oid,uid,message);

                Toast.makeText(context, "Order has been Canceled", Toast.LENGTH_SHORT).show();



            }
        });



    }

    @Override
    public int getItemCount() {
        return OrderModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView OrderSPID,OrderPNAME,OrderCNAME,OrderQTY,OrderPNUMBER,OrderLocation,OrderuserID,OrderID;
        ImageView OrderImage;
        Button Confirm,Cancel;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);


            OrderSPID=itemView.findViewById(R.id.orderspId);
            OrderPNAME=itemView.findViewById(R.id.orderproductname);
            OrderCNAME=itemView.findViewById(R.id.ordercategoryname);
            OrderQTY=itemView.findViewById(R.id.orderqty);
            OrderPNUMBER=itemView.findViewById(R.id.orderphonenumber);
            OrderLocation=itemView.findViewById(R.id.orderlocation);
            OrderImage=itemView.findViewById(R.id.orderimageView );
            OrderuserID=itemView.findViewById(R.id.orderusid);
            OrderID=itemView.findViewById(R.id.orderid);
            Confirm=itemView.findViewById(R.id.button);
            Cancel=itemView.findViewById(R.id.button1);



        }
    }
}
