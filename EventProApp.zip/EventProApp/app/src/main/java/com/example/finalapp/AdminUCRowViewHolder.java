package com.example.finalapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdminUCRowViewHolder extends RecyclerView.Adapter<AdminUCRowViewHolder.ViewHolder>{



    private ArrayList<UCClass> UCModalArrayList;
    private Context context;

    private DBHandler dbHandler;


    public AdminUCRowViewHolder(ArrayList<UCClass> UCModalArrayList, Context context) {
        this.UCModalArrayList = UCModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public AdminUCRowViewHolder.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.uc_row, parent, false);
        return new AdminUCRowViewHolder.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdminUCRowViewHolder.ViewHolder holder, int position) {

        UCClass modal = UCModalArrayList.get(position);//link adater to class
        byte[] image = modal.getProavatar();
        Bitmap bitmap = BitmapFactory.decodeByteArray(image,0,image.length);

        holder.UCID.setText("User ID : "+modal.getUCid());
        holder.UCUType.setText("User Type : "+modal.getUCusertype());
        holder.UCphonenumber.setText("User PhoneNumber : "+modal.getUCphonenumber());
        holder.UCEmail.setText("User Email : "+modal.getUCemail());
        holder.UCImage.setImageBitmap(bitmap);

        holder.Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHandler = new DBHandler(context);
                String Id = modal.getUCid();

                if(dbHandler.deleteUC(Id)){

                    Toast.makeText(context, "User Account Deleted", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(context, " Not Deleted", Toast.LENGTH_SHORT).show();

                }
            }
        });




    }

    @Override
    public int getItemCount() {
        return UCModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView UCID,UCUType,UCphonenumber,UCEmail;
        ImageView UCImage;
        Button Delete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            UCID=itemView.findViewById(R.id.ucId);
            UCUType=itemView.findViewById(R.id.ucusertype);
            UCphonenumber=itemView.findViewById(R.id.ucphonenumber);
            UCEmail=itemView.findViewById(R.id.ucemail);
            UCImage=itemView.findViewById(R.id.ucimageView);
            Delete=itemView.findViewById(R.id.ucdelete);



        }
    }
}
