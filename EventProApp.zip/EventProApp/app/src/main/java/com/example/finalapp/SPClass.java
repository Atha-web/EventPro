package com.example.finalapp;

public class SPClass {

    private String SPid;
    private String SPusertype;
    private String SPphonenumber;
    private String SPemail;
    private byte[] proavatar;

    public SPClass() {
    }

    public SPClass(String SPid, String SPusertype, String SPphonenumber, String SPemail, byte[] proavatar) {
        this.SPid = SPid;
        this.SPusertype = SPusertype;
        this.SPphonenumber = SPphonenumber;
        this.SPemail = SPemail;
        this.proavatar = proavatar;
    }

    public String getSPid() {
        return SPid;
    }

    public void setSPid(String SPid) {
        this.SPid = SPid;
    }

    public String getSPusertype() {
        return SPusertype;
    }

    public void setSPusertype(String SPusertype) {
        this.SPusertype = SPusertype;
    }

    public String getSPphonenumber() {
        return SPphonenumber;
    }

    public void setSPphonenumber(String SPphonenumber) {
        this.SPphonenumber = SPphonenumber;
    }

    public String getSPemail() {
        return SPemail;
    }

    public void setSPemail(String SPemail) {
        this.SPemail = SPemail;
    }

    public byte[] getProavatar() {
        return proavatar;
    }

    public void setProavatar(byte[] proavatar) {
        this.proavatar = proavatar;
    }
}

