package com.example.finalapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdminSPRowViewHolder extends RecyclerView.Adapter<AdminSPRowViewHolder.ViewHolder> {


    private ArrayList<SPClass> SPModalArrayList;
    private Context context;

    private DBHandler dbHandler;
    public AdminSPRowViewHolder(ArrayList<SPClass> SPModalArrayList, Context context) {
        this.SPModalArrayList = SPModalArrayList;
        this.context = context;
    }



    @NonNull
    @Override
    public AdminSPRowViewHolder.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sp_row, parent, false);
        return new AdminSPRowViewHolder.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdminSPRowViewHolder.ViewHolder holder, int position) {

        SPClass modal = SPModalArrayList.get(position);//link adater to class
        byte[] image = modal.getProavatar();
        Bitmap bitmap = BitmapFactory.decodeByteArray(image,0,image.length);

        holder.SPID.setText("Service Provider ID : "+modal.getSPid());
        holder.SPUType.setText("User Type : "+modal.getSPusertype());
        holder.SPphonenumber.setText("User PhoneNumber : "+modal.getSPphonenumber());
        holder.SPEmail.setText("User Email : "+modal.getSPemail());
        holder.SPImage.setImageBitmap(bitmap);

        holder.Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dbHandler = new DBHandler(context);
                String Id = modal.getSPid();

                if(dbHandler.deleteSP(Id)){

                   dbHandler.deleteSpProduct(Id);

                    Toast.makeText(context, "Service Provider Account Deleted", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(context, " Not Deleted", Toast.LENGTH_SHORT).show();

                }


            }
        });

        holder.View.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dbHandler = new DBHandler(context);
                String Id = modal.getSPid();

                Intent intent = new Intent(context,AdminSPProductActivity.class);
                intent.putExtra("Id",Id);
                context.startActivity(intent);



            }
        });




    }

    @Override
    public int getItemCount() {
        return SPModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView SPID,SPUType,SPphonenumber,SPEmail;
        ImageView SPImage;
        Button Delete,View;

        public ViewHolder(@NonNull android.view.View itemView) {
            super(itemView);

            SPID=itemView.findViewById(R.id.spId);
            SPUType=itemView.findViewById(R.id.spusertype);
            SPphonenumber=itemView.findViewById(R.id.spphonenumber);
            SPEmail=itemView.findViewById(R.id.spemail);
            SPImage=itemView.findViewById(R.id.spimageView);
            Delete=itemView.findViewById(R.id.spdelete);
            View=itemView.findViewById(R.id.spviewproduct);


        }
    }
}
