package com.example.finalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class S_P_CategoryProductActivity extends AppCompatActivity {





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sp_category_product);



        RecyclerView recyclerView = findViewById(R.id.rv);
        List<CategoryClass> items = new ArrayList<CategoryClass>();

        items.add(new CategoryClass("1000","Birthday Events(1000)", R.drawable.birt));
        items.add(new CategoryClass("2000","Wedding Events(2000)",R.drawable.wedd));
        items.add(new CategoryClass("3000","Co Opreate Events(3000)",R.drawable.event));
        items.add(new CategoryClass("4000","Catering(4000)",R.drawable.cater));
        items.add(new CategoryClass("5000","Floral(5000)",R.drawable.flor));
        items.add(new CategoryClass("6000","Cars(6000)",R.drawable.wedc));
        items.add(new CategoryClass("7000","Others(7000)",R.drawable.oth));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new CategoryAdapter(getApplicationContext(),items));

        String SPID = getIntent().getStringExtra("SPID");






        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_Navigation);

        bottomNavigationView.setSelectedItemId(R.id.View);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                if(menuItem.getItemId()== R.id.View){
                    return  true;

                } else if (menuItem.getItemId()== R.id.Add) {
                Intent intent = new Intent(S_P_CategoryProductActivity.this,S_P_AddProductAvtivity.class);
                intent.putExtra("SPID",SPID);
                startActivity(intent);
                    overridePendingTransition(0,0);

                } else if (menuItem.getItemId()== R.id.Search) {//S_P_SearchProductActivity
                    Intent intent = new Intent(S_P_CategoryProductActivity.this,S_P_SearchProductActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);

                }
                else if (menuItem.getItemId()== R.id.Order) {//S_P_ViewOrderActivity
                    Intent intent = new Intent(S_P_CategoryProductActivity.this,S_P_ViewOrderActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                }
                else if (menuItem.getItemId()== R.id.Query) {//S_P_ViewQueryActivity
                    Intent intent = new Intent(S_P_CategoryProductActivity.this,S_P_ViewQueryActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                }

                return false;
            }
        });



    }



}