package com.example.finalapp;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class U_ViewCatProductActivity extends AppCompatActivity {


    private ArrayList<ProductClass> ProductModelArrayList;
    private DBHandler dbHandler;
    private U_ProductRowViewUserHolder ProductRvAdapter;
    private RecyclerView SearchProductRV;
    String c_category_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uview_cat_product2);

        c_category_id = getIntent().getStringExtra("categoryID");

        ProductModelArrayList = new ArrayList<>();
        dbHandler = new DBHandler(U_ViewCatProductActivity.this);

        ProductModelArrayList = dbHandler.Category_Allproduct(c_category_id);



        ProductRvAdapter = new U_ProductRowViewUserHolder(ProductModelArrayList, U_ViewCatProductActivity.this);
        SearchProductRV = findViewById(R.id.cat_pro_rv00);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(U_ViewCatProductActivity.this, RecyclerView.VERTICAL, false);
        SearchProductRV.setLayoutManager(linearLayoutManager);

        SearchProductRV.setAdapter(ProductRvAdapter);

        if (ProductModelArrayList.size() != 0) {

            Toast.makeText(U_ViewCatProductActivity.this, "Product  Found", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(U_ViewCatProductActivity.this, "Product Not Found", Toast.LENGTH_SHORT).show();

        }



    }
}