package com.example.finalapp;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.ByteArrayOutputStream;

public class S_P_AddProductAvtivity extends AppCompatActivity {

    private EditText P_S_P_ID,P_productID,P_productName,P_productQty,P_productPrice,P_productDetails;

    private Spinner P_categoryID,P_categoryName;
    private ImageView P_imageview,imagecamera,imagegallery;
    private Button P_addProduct,back;
    AlertDialog.Builder builder;

    String categoryName_type[]={"Wedding Events(2000)","Birthday Events(1000)","Co Opreate Events(3000)","Catering(4000)","Floral(5000)","Cars(6000)","others(7000)"};
    String categoryID_type[]={"2000","1000","3000","4000","5000","6000","7000"};

    private DBHandler dbHandler ;
    String SPID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sp_add_product_avtivity);

        dbHandler = new DBHandler(S_P_AddProductAvtivity.this);
        builder = new AlertDialog.Builder(this);

        P_S_P_ID=findViewById(R.id.pserviceproviderid);
        P_productID=findViewById(R.id.pproductid);
        P_productName=findViewById(R.id.pproductname);
        P_productQty=findViewById(R.id.pproducqty);
        P_productPrice=findViewById(R.id.pproductprice);
        P_productDetails=findViewById(R.id.pproductdetails);
        P_categoryID=findViewById(R.id.pcetagoryid);
        P_categoryName=findViewById(R.id.pcetagoryname);
        P_addProduct=findViewById(R.id.paddbutton);
        P_imageview=findViewById(R.id.pimageView);
        back=findViewById(R.id.buttonback7);

        SPID = getIntent().getStringExtra("SPID");
        P_S_P_ID.setText(SPID);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(S_P_AddProductAvtivity.this, S_P_ProviderHomeAvtivtiy.class);
                i.putExtra("SPID",SPID);
                startActivity(i);
            }
        });



        ArrayAdapter ad1=new ArrayAdapter(this,android.R.layout.simple_spinner_item,categoryName_type);
        ad1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        P_categoryName.setAdapter(ad1);


        ArrayAdapter ad2=new ArrayAdapter(this,android.R.layout.simple_spinner_item,categoryID_type);
        ad2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        P_categoryID.setAdapter(ad2);

        P_imageview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChooseProfilePicture();
            }
        });


        P_addProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(P_S_P_ID.getText().toString().isEmpty()||
                        P_productID.getText().toString().isEmpty()||
                        P_productName.getText().toString().isEmpty()||
                        P_productQty.getText().toString().isEmpty()||
                        P_productPrice.getText().toString().isEmpty()||
                        P_productDetails.getText().toString().isEmpty())
                {
                    Toast.makeText(getApplicationContext(),
                            "Fields can't be blank",Toast.LENGTH_LONG).show();
                }
                else{

                    String S_P_Id = P_S_P_ID.getText().toString();
                    String S_P_productId = P_productID.getText().toString();
                    String S_P_productName= P_productName.getText().toString();
                    String S_P_productPrice = P_productPrice.getText().toString();
                    String S_P_productQty = P_productQty.getText().toString();
                    String S_P_productAbout = P_productDetails.getText().toString();
                    String S_P_CategoryName = P_categoryName.getSelectedItem().toString();
                    String S_P_CategoryId = P_categoryID.getSelectedItem().toString();

                    byte[] byteSSP = covertImageToByteArray(P_imageview);

                    if( dbHandler.addNewProduct(S_P_Id, S_P_productId, S_P_productName,S_P_CategoryId,S_P_CategoryName, S_P_productPrice,S_P_productQty,S_P_productAbout,byteSSP)){


                        builder.setTitle(" Add Product Form...")
                                .setMessage(" Product Added Succesfully..")
                                .setIcon(R.drawable.baseline_add_task_24)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int i) {
                                        dialog.cancel();
                                    }
                                }).show();


                        Toast.makeText(S_P_AddProductAvtivity.this, "New Product Added .", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(S_P_AddProductAvtivity.this, "New Product Not Added .", Toast.LENGTH_SHORT).show();
                    }


                }
            }
        });







        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_Navigation);

        bottomNavigationView.setSelectedItemId(R.id.Add);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                if(menuItem.getItemId()== R.id.View){//S_P_CategoryProductActivity
                    Intent intent = new Intent(S_P_AddProductAvtivity.this,S_P_CategoryProductActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                } else if (menuItem.getItemId()== R.id.Add) {
                    return  true;

                } else if (menuItem.getItemId()== R.id.Search) {//S_P_SearchProductActivity
                    Intent intent = new Intent(S_P_AddProductAvtivity.this,S_P_SearchProductActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                }
                else if (menuItem.getItemId()== R.id.Order) {//S_P_ViewOrderActivity
                    Intent intent = new Intent(S_P_AddProductAvtivity.this,S_P_ViewOrderActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                }
                else if (menuItem.getItemId()== R.id.Query) {//S_P_ViewQueryActivity
                    Intent intent = new Intent(S_P_AddProductAvtivity.this,S_P_ViewQueryActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                }
                return false;
            }
        });



    }

    private byte[] covertImageToByteArray(ImageView imageView) {
        Bitmap bitmap = ((BitmapDrawable) imageView.getDrawable()).
                getBitmap();
        ByteArrayOutputStream byteArrayOutputStream =
                new ByteArrayOutputStream();

        bitmap.compress(Bitmap.CompressFormat.JPEG, 80,
                byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }
    private void ChooseProfilePicture() {

        AlertDialog.Builder builder =
                new AlertDialog.Builder(S_P_AddProductAvtivity.this);
        LayoutInflater inflater = getLayoutInflater();

        View dialogView =
                inflater.inflate(R.layout.alert_dialog_picture, null);
        builder.setCancelable(false);
        builder.setView(dialogView);

        imagecamera = dialogView.findViewById(R.id.imageViewDPPCamera);
        imagegallery = dialogView.findViewById(R.id.imageViewDPPGallery);
        final AlertDialog alertDialogProfilePicture = builder.create();
        alertDialogProfilePicture.show();

        imagecamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkAndRequestPermission()) {
                    takePictureFromCamera();
                    alertDialogProfilePicture.cancel();
                }
            }
        });

        imagegallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takePictureFromGallery();
                alertDialogProfilePicture.cancel();
            }
        });

    }


    private void takePictureFromCamera() {
        Intent takePicture=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(takePicture.resolveActivity(getPackageManager())!=null)
        {
            startActivityForResult(takePicture,2);
        }
    }

    private void takePictureFromGallery() {

        Intent pickPhoto=new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(pickPhoto,1);
    }

    private boolean checkAndRequestPermission() {

        if(Build.VERSION.SDK_INT>23)
        {
            int  cameraPermission=
                    ActivityCompat.checkSelfPermission
                            (S_P_AddProductAvtivity.this,
                                    Manifest.permission.CAMERA);
            if(cameraPermission== PackageManager.PERMISSION_DENIED)
            {
                ActivityCompat.requestPermissions
                        (S_P_AddProductAvtivity.this,new String[]
                                {Manifest.permission.CAMERA},20);
                return false;
            }
        }
        return true;


    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode)
        {
            case 1:
                if(resultCode==RESULT_OK)
                {
                    Uri selectImageUri=data.getData();
                    P_imageview.setImageURI(selectImageUri);
                }
                break;
            case 2:
                if(resultCode==RESULT_OK)
                {
                    Bundle bundle=data.getExtras();
                    Bitmap bitmapImage=(Bitmap) bundle.get("data");
                    P_imageview.setImageBitmap(bitmapImage);
                }
                break;
        }

    }
}