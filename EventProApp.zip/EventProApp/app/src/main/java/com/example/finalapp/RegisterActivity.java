package com.example.finalapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class RegisterActivity extends AppCompatActivity {

    private Button register_button,back;
    private EditText re_UserID,re_Password,re_ConfirmPassword,re_PhoneNumber,re_EmailID;
    private ImageView re_Imageview,imagecamera,imagegallery;
    private Spinner re_Spinner;

    String re_usertype[]={"Service_Provider","User"};//Array was created to show usertype values

    private DBHandler dbHandler ;
    AlertDialog.Builder builder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        dbHandler = new DBHandler(RegisterActivity.this);


        register_button=findViewById(R.id.regbutton);
        back=findViewById(R.id.buttonback1);
        re_UserID=findViewById(R.id.editTextregisterusername);
        re_Password=findViewById(R.id.editTextregisterpassword);
        re_ConfirmPassword=findViewById(R.id.editTextregistercofirmpassword);
        re_PhoneNumber=findViewById(R.id.editTextregisterphonenumber);
        re_EmailID=findViewById(R.id.editTextregisteremailid);
        re_Imageview=findViewById(R.id.imageViewuser);
        re_Spinner=findViewById(R.id.spinnerregisterusertype);
        builder = new AlertDialog.Builder(this);



        ArrayAdapter ad=new ArrayAdapter(this,android.R.layout.simple_spinner_item,re_usertype);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        re_Spinner.setAdapter(ad);//Array Adapter is used to display Array usertype values in Spinner


        re_Imageview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ChooseProfilePicture();
            }
        });


        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(re_UserID.getText().toString().isEmpty()||
                        re_Password.getText().toString().isEmpty()||
                        re_ConfirmPassword.getText().toString().isEmpty())

                {
                    Toast.makeText(getApplicationContext(),
                            "Fields can't be blank",Toast.LENGTH_LONG).show();
                }
                else if (re_Password.getText().toString().length()<3)
                {
                    Toast.makeText(getApplicationContext(),
                            "Password must have more than 3 characters",
                            Toast.LENGTH_LONG).show();

                }
                else if (!re_Password.getText().toString().equals(re_ConfirmPassword.getText().toString()))
                {
                    Toast.makeText(getApplicationContext(),
                            "Password and confirm password should match",Toast.LENGTH_LONG).show();
                }
                else{

                    String UserName = re_UserID.getText().toString();
                    String Password = re_Password.getText().toString();
                    String UserType = re_Spinner.getSelectedItem().toString();
                    String PhoneNumber= re_PhoneNumber.getText().toString();
                    String Email = re_EmailID.getText().toString();
                    byte[] byteSSP = covertImageToByteArray(re_Imageview);

                    if( dbHandler.addNewUser(UserName, Password, UserType,PhoneNumber,Email, byteSSP)){


                        builder.setTitle(" Register Form ...")
                                .setMessage("New User Created Succesfully... ")
                                .setIcon(R.drawable.baseline_add_task_24)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int i) {
                                        dialog.cancel();
                                    }
                                }).show();


                        Toast.makeText(RegisterActivity.this, "New User Created.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(RegisterActivity.this, "New User Not Created.", Toast.LENGTH_SHORT).show();
                    }

                }



            }
        });


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(RegisterActivity.this,LoginActivity.class);
                startActivity(i);
            }
        });




    }



    private byte[] covertImageToByteArray(ImageView re_imageview) {

        Bitmap bitmap = ((BitmapDrawable) re_imageview.getDrawable()).
                getBitmap();
        ByteArrayOutputStream byteArrayOutputStream =
                new ByteArrayOutputStream();

        bitmap.compress(Bitmap.CompressFormat.JPEG, 80,
                byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    private void ChooseProfilePicture() {

        AlertDialog.Builder builder =
                new AlertDialog.Builder(RegisterActivity.this);
        LayoutInflater inflater = getLayoutInflater();

        View dialogView =
                inflater.inflate(R.layout.alert_dialog_picture, null);
        builder.setCancelable(false);
        builder.setView(dialogView);

        imagecamera = dialogView.findViewById(R.id.imageViewDPPCamera);
        imagegallery = dialogView.findViewById(R.id.imageViewDPPGallery);
        final AlertDialog alertDialogProfilePicture = builder.create();
        alertDialogProfilePicture.show();

        imagecamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkAndRequestPermission()) {
                    takePictureFromCamera();
                    alertDialogProfilePicture.cancel();
                }
            }
        });

        imagegallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takePictureFromGallery();
                alertDialogProfilePicture.cancel();
            }
        });



    }

    private void takePictureFromCamera() {

        Intent takePicture=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(takePicture.resolveActivity(getPackageManager())!=null)
        {
            startActivityForResult(takePicture,2);
        }
    }

    private void takePictureFromGallery() {

        Intent pickPhoto=new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(pickPhoto,1);
    }

    private boolean checkAndRequestPermission() {
        if(Build.VERSION.SDK_INT>23)
        {
            int  cameraPermission=
                    ActivityCompat.checkSelfPermission
                            (RegisterActivity.this,
                                    android.Manifest.permission.CAMERA);
            if(cameraPermission== PackageManager.PERMISSION_DENIED)
            {
                ActivityCompat.requestPermissions
                        (RegisterActivity.this,new String[]
                                {Manifest.permission.CAMERA},20);
                return false;
            }
        }
        return true;
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode)
        {
            case 1:
                if(resultCode==RESULT_OK)
                {
                    Uri selectImageUri=data.getData();
                    re_Imageview.setImageURI(selectImageUri);
                }
                break;
            case 2:
                if(resultCode==RESULT_OK)
                {
                    Bundle bundle=data.getExtras();
                    Bitmap bitmapImage=(Bitmap) bundle.get("data");
                    re_Imageview.setImageBitmap(bitmapImage);
                }
                break;
        }

    }





}