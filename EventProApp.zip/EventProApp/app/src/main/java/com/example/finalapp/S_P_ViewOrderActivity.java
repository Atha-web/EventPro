package com.example.finalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class S_P_ViewOrderActivity extends AppCompatActivity {

    private DBHandler dbHandler ;

    private ArrayList<OrderClass> OrderModelArrayList;
    private S_OrderRowViewHolder OrderRvAdapter;
    private RecyclerView SearchOrderRV;



    Button back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sp_view_order);
        dbHandler = new DBHandler(S_P_ViewOrderActivity.this);


        String SPID = getIntent().getStringExtra("SPID");

        OrderModelArrayList = new ArrayList<>();

        OrderModelArrayList = dbHandler.SearchOder2(SPID);

        OrderRvAdapter = new S_OrderRowViewHolder(OrderModelArrayList, S_P_ViewOrderActivity.this);
        SearchOrderRV = findViewById(R.id.or_rv2);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(S_P_ViewOrderActivity.this, RecyclerView.VERTICAL, false);
        SearchOrderRV.setLayoutManager(linearLayoutManager);

        SearchOrderRV.setAdapter(OrderRvAdapter);


        if (OrderModelArrayList.size() != 0) {

            Toast.makeText(S_P_ViewOrderActivity.this, "Order  Found", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(S_P_ViewOrderActivity.this, "Order Not Found", Toast.LENGTH_SHORT).show();
            Toast.makeText(S_P_ViewOrderActivity.this, "Please Check your ID", Toast.LENGTH_SHORT).show();

        }





        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_Navigation);

        bottomNavigationView.setSelectedItemId(R.id.Order);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                if(menuItem.getItemId()== R.id.View){//S_P_CategoryProductActivity
                    Intent intent = new Intent(S_P_ViewOrderActivity.this,S_P_CategoryProductActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                } else if (menuItem.getItemId()== R.id.Add) {//S_P_AddProductAvtivity
                    Intent intent = new Intent(S_P_ViewOrderActivity.this,S_P_AddProductAvtivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);

                } else if (menuItem.getItemId()== R.id.Search) {//S_P_SearchProductActivity
                    Intent intent = new Intent(S_P_ViewOrderActivity.this,S_P_SearchProductActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                }
                else if (menuItem.getItemId()== R.id.Order) {
                    return  true;
                }
                else if (menuItem.getItemId()== R.id.Query) {//S_P_ViewQueryActivity
                    Intent intent = new Intent(S_P_ViewOrderActivity.this,S_P_ViewQueryActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                }

                return false;
            }
        });



    }


}