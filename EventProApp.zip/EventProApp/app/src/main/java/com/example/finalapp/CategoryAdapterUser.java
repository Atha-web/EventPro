package com.example.finalapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CategoryAdapterUser extends RecyclerView.Adapter<CategoryViewHolderUser>{



    /*
       1. Create a Category class to display related details through the RecyclerView adapter.
        It will help to get data from database and provide it to the adapter.

       2. Create a single line to show what should be shown through the adapter in the recycleView.
          edittext imagevew like that  create in single row.

       3.Assigns row IDs to variables created in the view holder.

       4.Using intent we can move the data in recyclerview to another activity.



     */

    Context context;
    List<CategoryClass> items;

    public CategoryAdapterUser(Context context, List<CategoryClass> items) {
        this.context = context;// The constructor is used to put Categorydata into the recycler thoruth adapter.
        this.items = items;
    }


    @NonNull
    @Override
    public CategoryViewHolderUser onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //connect the sigle row to Recylcevikewadater
        return new CategoryViewHolderUser(LayoutInflater.from(context).inflate(R.layout.ca_row,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolderUser holder, int position) {

        CategoryClass categoryItem = items.get(position);//link adater to class
// The data taken from the class is put into variables related to the single row.using getter and settet method .
        holder.idview.setText(items.get(position).getCategory_ID());
        holder.nameview.setText(items.get(position).getCategory_Name());
        holder.imageView.setImageResource(items.get(position).getImage());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Using intent we can move the data in recyclerview to another activity.
                Intent intent = new Intent(context, U_ViewCatProductActivity.class);
                intent.putExtra("categoryID", categoryItem.getCategory_ID());
                // intent.putExtra("categoryName","Category Name : "+categoryItem.getCategory_Name());
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);

            }
        });
    }



    @Override
    public int getItemCount() {
        return items.size();
    }
}
