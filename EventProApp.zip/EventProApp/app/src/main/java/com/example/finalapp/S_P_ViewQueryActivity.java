package com.example.finalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class S_P_ViewQueryActivity extends AppCompatActivity {

    private DBHandler dbHandler ;
    private ArrayList<QueryClass> QueryModelArrayList;
    private QueryViewRowHolder QueryRvAdapter;
    private RecyclerView SearchQueryRV;

    Button back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sp_view_query);


        String SPID = getIntent().getStringExtra("SPID");

        dbHandler = new DBHandler(S_P_ViewQueryActivity.this);


        QueryModelArrayList = new ArrayList<>();
        QueryModelArrayList = dbHandler.SearchQuery2(SPID);

        QueryRvAdapter = new QueryViewRowHolder(QueryModelArrayList, S_P_ViewQueryActivity.this);
        SearchQueryRV = findViewById(R.id.q_rv2);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(S_P_ViewQueryActivity.this, RecyclerView.VERTICAL, false);
        SearchQueryRV.setLayoutManager(linearLayoutManager);

        SearchQueryRV.setAdapter(QueryRvAdapter);


        if (QueryModelArrayList.size() != 0) {

            Toast.makeText(S_P_ViewQueryActivity.this, "Query  Found", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(S_P_ViewQueryActivity.this, "Query Not Found", Toast.LENGTH_SHORT).show();
            Toast.makeText(S_P_ViewQueryActivity.this, "Please Check your ID", Toast.LENGTH_SHORT).show();

        }

















        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_Navigation);

        bottomNavigationView.setSelectedItemId(R.id.Query);



        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                if(menuItem.getItemId()== R.id.View){//S_P_CategoryProductActivity
                    Intent intent = new Intent(S_P_ViewQueryActivity.this,S_P_CategoryProductActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                } else if (menuItem.getItemId()== R.id.Add) {//S_P_AddProductAvtivity
                    Intent intent = new Intent(S_P_ViewQueryActivity.this,S_P_AddProductAvtivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);

                } else if (menuItem.getItemId()== R.id.Search) {//S_P_SearchProductActivity
                    Intent intent = new Intent(S_P_ViewQueryActivity.this,S_P_SearchProductActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                }
                else if (menuItem.getItemId()== R.id.Order) {//S_P_ViewOrderActivity
                    Intent intent = new Intent(S_P_ViewQueryActivity.this,S_P_ViewOrderActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                }
                else if (menuItem.getItemId()== R.id.Query) {
                    return  true;
                }

                return false;
            }
        });



    }


}