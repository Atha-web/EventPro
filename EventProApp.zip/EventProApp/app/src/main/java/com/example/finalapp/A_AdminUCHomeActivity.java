package com.example.finalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class A_AdminUCHomeActivity extends AppCompatActivity {

    private ArrayList<UCClass> UCModelArrayList;
    private DBHandler dbHandler;
    private AdminUCRowViewHolder UCRvAdapter;
    private RecyclerView SearchUCRV;

    Button logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_uchome);



        UCModelArrayList = new ArrayList<>();
        dbHandler = new DBHandler(A_AdminUCHomeActivity.this);

        String type="User";
        UCModelArrayList = dbHandler.SearchType1(type);

        UCRvAdapter = new AdminUCRowViewHolder(UCModelArrayList, A_AdminUCHomeActivity.this);
        SearchUCRV = findViewById(R.id.uc_rc);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(A_AdminUCHomeActivity.this, RecyclerView.VERTICAL, false);
        SearchUCRV.setLayoutManager(linearLayoutManager);
        SearchUCRV.setAdapter(UCRvAdapter);

        if (UCModelArrayList.size() != 0) {

            Toast.makeText(A_AdminUCHomeActivity.this, "User Found", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(A_AdminUCHomeActivity.this, "User Not Found", Toast.LENGTH_SHORT).show();
        }












        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_Navigation3);

        bottomNavigationView.setSelectedItemId(R.id.UC);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                if(menuItem.getItemId()== R.id.SP){

                    Intent intent = new Intent(A_AdminUCHomeActivity.this,A_AdminSPHomeActivity.class);
                    startActivity(intent);
                    overridePendingTransition(0,0);

                } else if (menuItem.getItemId()== R.id.UC) {

                    return  true;

                }
                return false;
            }
        });


    }
}