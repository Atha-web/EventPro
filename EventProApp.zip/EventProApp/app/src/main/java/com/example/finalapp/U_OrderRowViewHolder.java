package com.example.finalapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class U_OrderRowViewHolder extends RecyclerView.Adapter<U_OrderRowViewHolder.ViewHolder> {

    DBHandler dbHandler;
    AlertDialog.Builder builder;
    private ArrayList<OrderClass> OrderModalArrayList;
    private Context context;


    public U_OrderRowViewHolder(ArrayList<OrderClass> orderModalArrayList, Context context) {
        OrderModalArrayList = orderModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public U_OrderRowViewHolder.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_row, parent, false);
        return new U_OrderRowViewHolder.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull U_OrderRowViewHolder.ViewHolder holder, int position) {

        OrderClass modal = OrderModalArrayList.get(position);//link adater to class
        byte[] image = modal.getProavatar();
        Bitmap bitmap = BitmapFactory.decodeByteArray(image,0,image.length);

        dbHandler = new DBHandler(context);

        holder.OrderID.setText(modal.getOrderid());
        holder.OrderuserID.setText("User ID : "+modal.getOrderUSid());
        holder.OrderSPID.setText(modal.getOrderSPid());
        holder.OrderPNAME.setText(modal.getOrderproductname());
        holder.OrderCNAME.setText(modal.getOrdercategoryname());
        holder.OrderPNUMBER.setText("User Contact : "+modal.getOrderusernumber());
        holder.OrderQTY.setText("Product QTY : "+modal.getOrderproducteqty());
        holder.OrderLocation.setText("User Location : "+modal.getOrderuserlocation());
        holder.OrderImage.setImageBitmap(bitmap);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             /*   Intent intent = new Intent(context, U_ConfirmMessageActivity.class);

                // Using intent we can move the data in recyclerview to another activity.
                intent.putExtra("O_ID",modal.getOrderid());
                intent.putExtra("Product_Name",modal.getOrderproductname());
                intent.putExtra("USID",modal.getOrderUSid());

                context.startActivity(intent);*/


                builder = new AlertDialog.Builder(context);
                dbHandler= new DBHandler(context);

                String id = modal.getOrderid();

                ArrayList<ConfrimClass> orderDetails =
                        dbHandler.validOrder(id);

                if (orderDetails.size() != 0) {//check the details have or not ,if have data we can continue

                    ConfrimClass order = orderDetails.get(0);
                    String message = order.getMessage();

                    if (message.equals("Order has been Confirmed")) {

                        builder.setTitle("Order Confirmation")
                                .setMessage(" Order has been Confirmed")
                                .setIcon(R.drawable.baseline_message_24)
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int i) {
                                        //   redirectActivity(S_P_ProviderHomeAvtivtiy.this, LoginActivity.class);
                                        //    Intent intent = new Intent(U_ConfirmMessageActivity.this,U_C_OrderViewActivity.class);
                                        //     intent.putExtra("USID",USID);
                                        //   startActivity(intent);

                                    }
                                })
                                .show();


                    } else if (message.equals("Order has been Canceled")) {

                        builder.setTitle("Order Confirmation")
                                .setMessage(" Order has been Canceled")
                                .setIcon(R.drawable.baseline_message_24)
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int i) {
                                        //   redirectActivity(S_P_ProviderHomeAvtivtiy.this, LoginActivity.class);
                                    //    Intent intent = new Intent(U_ConfirmMessageActivity.this,U_C_OrderViewActivity.class);
                                     //   intent.putExtra("USID",USID);
                                    //    startActivity(intent);

                                    }
                                })
                                .show();

                    }
                    else if(message.equals("")){

                        builder.setTitle("Order Confirmation")
                                .setMessage(" Order Pending.......")

                                .setIcon(R.drawable.baseline_message_24)
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int i) {
                                        //   redirectActivity(S_P_ProviderHomeAvtivtiy.this, LoginActivity.class);
                                      //  Intent intent = new Intent(U_ConfirmMessageActivity.this,U_C_OrderViewActivity.class);
                                    //    intent.putExtra("USID",USID);
                                    //    startActivity(intent);

                                    }
                                })
                                .show();

                    }
                }
                else{
                    builder.setTitle("Order Confirmation")
                            .setMessage(" Order Pending.......")

                            .setIcon(R.drawable.baseline_message_24)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int i) {
                                    //   redirectActivity(S_P_ProviderHomeAvtivtiy.this, LoginActivity.class);
                                    //  Intent intent = new Intent(U_ConfirmMessageActivity.this,U_C_OrderViewActivity.class);
                                    //    intent.putExtra("USID",USID);
                                    //    startActivity(intent);

                                }
                            })
                            .show();
                }





            }
        });




    }

    @Override
    public int getItemCount() {
        return OrderModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView OrderSPID,OrderPNAME,OrderCNAME,OrderQTY,OrderPNUMBER,OrderLocation,OrderuserID,OrderID,oderconfirm,ordercancel,orderpending;
        ImageView OrderImage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);


            OrderSPID=itemView.findViewById(R.id.orderspId);
            OrderPNAME=itemView.findViewById(R.id.orderproductname);
            OrderCNAME=itemView.findViewById(R.id.ordercategoryname);
            OrderQTY=itemView.findViewById(R.id.orderqty);
            OrderPNUMBER=itemView.findViewById(R.id.orderphonenumber);
            OrderLocation=itemView.findViewById(R.id.orderlocation);
            OrderImage=itemView.findViewById(R.id.orderimageView );
            OrderuserID=itemView.findViewById(R.id.orderusid);
            OrderID=itemView.findViewById(R.id.orderid );
            oderconfirm=itemView.findViewById(R.id.orderconfirm);
            ordercancel=itemView.findViewById(R.id.ordercancel);
            orderpending=itemView.findViewById(R.id.orderpending);

        }
    }
}
