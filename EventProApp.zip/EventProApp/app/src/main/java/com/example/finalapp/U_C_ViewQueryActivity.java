package com.example.finalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class U_C_ViewQueryActivity extends AppCompatActivity {



    private DBHandler dbHandler ;
    private ArrayList<QueryClass> QueryModelArrayList;
    private QueryViewRowHolder QueryRvAdapter;
    private RecyclerView SearchQueryRV;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uc_view_query);


        String USID = getIntent().getStringExtra("USID");

        dbHandler = new DBHandler(U_C_ViewQueryActivity.this);


        QueryModelArrayList = new ArrayList<>();
        QueryModelArrayList = dbHandler.SearchQuery(USID);

        QueryRvAdapter = new QueryViewRowHolder(QueryModelArrayList, U_C_ViewQueryActivity.this);
        SearchQueryRV = findViewById(R.id.q_rv);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(U_C_ViewQueryActivity.this, RecyclerView.VERTICAL, false);
        SearchQueryRV.setLayoutManager(linearLayoutManager);

        SearchQueryRV.setAdapter(QueryRvAdapter);


        if (QueryModelArrayList.size() != 0) {

            Toast.makeText(U_C_ViewQueryActivity.this, "Query  Found", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(U_C_ViewQueryActivity.this, "Query Not Found", Toast.LENGTH_SHORT).show();
            Toast.makeText(U_C_ViewQueryActivity.this, "Please Check your ID", Toast.LENGTH_SHORT).show();

        }











        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_Navigation1);

        bottomNavigationView.setSelectedItemId(R.id.View1);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                if(menuItem.getItemId()== R.id.View1){

                    return  true;

                } else if (menuItem.getItemId()== R.id.Search1) {
                    Intent intent = new Intent(U_C_ViewQueryActivity.this,U_C_ProductSearchActivity.class);
                    intent.putExtra("USID",USID);
                    startActivity(intent);
                    overridePendingTransition(0,0);

                } else if (menuItem.getItemId()== R.id.Query1) {
                    Intent intent = new Intent(U_C_ViewQueryActivity.this, U_C_QueryActivity.class);
                    intent.putExtra("USID",USID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                }
                else if (menuItem.getItemId()== R.id.Order1) {

                    Intent intent = new Intent(U_C_ViewQueryActivity.this,U_C_OrderViewActivity.class);
                    intent.putExtra("USID",USID);
                    startActivity(intent);

                    overridePendingTransition(0,0);

                }
                return false;
            }
        });

    }

}