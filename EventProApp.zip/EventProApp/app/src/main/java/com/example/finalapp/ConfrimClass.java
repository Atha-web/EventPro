package com.example.finalapp;

public class ConfrimClass {

    String OderId;
    String Message;

    public ConfrimClass() {
    }

    public ConfrimClass(String oderId, String message) {
        OderId = oderId;
        Message = message;
    }

    public String getOderId() {
        return OderId;
    }

    public void setOderId(String oderId) {
        OderId = oderId;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }
}
