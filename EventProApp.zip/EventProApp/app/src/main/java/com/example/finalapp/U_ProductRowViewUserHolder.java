package com.example.finalapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class U_ProductRowViewUserHolder extends RecyclerView.Adapter<U_ProductRowViewUserHolder.ViewHolder> {
    /*
       1. Create a Product class to display related details through the RecyclerView adapter.
        It will help to get data from database and provide it to the adapter.

       2. Create a single line to show what should be shown through the adapter in the recycleView.
          edittext imagevew like that  create in single row.

       3.Assigns row IDs to variables created in the view holder.

       4.Using intent we can move the data in recyclerview to another activity.



     */
    private ArrayList<ProductClass> ProductModalArrayList;
    private Context context;

    public U_ProductRowViewUserHolder(ArrayList<ProductClass> productModalArrayList, Context context) {
        // The constructor is used to put userinputdata or other data into the recycler thoruth adapter.
        ProductModalArrayList = productModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public U_ProductRowViewUserHolder.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //connect the sigle row to Recylcevikewadater
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pro_row, parent, false);
        return new U_ProductRowViewUserHolder.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull U_ProductRowViewUserHolder.ViewHolder holder, int position) {
        /*

        * The image id cannot be used to get and enter other variable data as usual.
       it is use for byte[] array type varible and Blob data type use.
       and Can't put it at once after assigning, can put it through bitmap.
        *
         We have to use bitmap to insert and retrieve image into database.
         After the byte[] array, the imageview id should be put into the bitmap.
         It is converted so that the image can be taken and inserted.

         */
        ProductClass modal = ProductModalArrayList.get(position);//link adater to class
        byte[] image = modal.getProavatar();
        Bitmap bitmap = BitmapFactory.decodeByteArray(image,0,image.length);


        // The data taken from the class is put into variables related to the single row.using getter and settet method .

        holder.SP_id.setText("S_Provider ID : "+modal.getSPid());
        holder.product_name.setText("Product Name : "+modal.getProductname());
        holder.category_name.setText("Cetagory Name : "+modal.getCategoryname());
        holder.product_Price.setText("Product Price : "+modal.getProductprice());
        holder.product_Details.setText("Product Details : "+modal.getProductDetilas());
        holder.product_imageView.setImageBitmap(bitmap);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, U_PrdouctDetailsViewUserAcitvity.class);

                // Using intent we can move the data in recyclerview to another activity.
                intent.putExtra("SP_ID",modal.getSPid());
                intent.putExtra("Product_Name","Product Name :: "+modal.getProductname());
                intent.putExtra("Category_Name","Category Name :: "+modal.getCategoryname());
                intent.putExtra("Product_Price","Product Price :: "+modal.getProductprice());
                intent.putExtra("Product_Details","Product Details :: "+modal.getProductDetilas());
                intent.putExtra("Image",image);
                context.startActivity(intent);


            }
        });
    }

    @Override
    public int getItemCount() {
        return ProductModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView SP_id,product_name,category_name,product_Price,product_Details;
        private ImageView product_imageView;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            //3.Assigns single row IDs to variables created in the view holder.
            SP_id=itemView.findViewById(R.id.viewspId);
            product_name=itemView.findViewById(R.id.viewproductname);
            category_name=itemView.findViewById(R.id.viewcategoryname);
            product_Price=itemView.findViewById(R.id.viewproductprice);
            product_imageView=itemView.findViewById(R.id.catimageView);
            product_Details=itemView.findViewById(R.id.viewproductdetails);
        }
    }
}
