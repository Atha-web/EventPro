package com.example.finalapp;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CategoryViewHolder extends RecyclerView.ViewHolder {

    ImageView imageView;
    TextView idview,nameview;


    public CategoryViewHolder(@NonNull View itemView) {
        super(itemView);

        //3.Assigns single row IDs to variables created in the view holder.

     imageView=itemView.findViewById(R.id.catimageView);
     idview=itemView.findViewById(R.id.catid);
     nameview=itemView.findViewById(R.id.catname);


    }
}
