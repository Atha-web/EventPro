package com.example.finalapp;

public class OrderClass {


    private String Orderid;
    private String OrderUSid;
    private String OrderSPid;
    private String Orderproductname;
    private String Ordercategoryname;
    private String Orderproducteqty;
    private String Orderusernumber;
    private String Orderuserlocation;
    private byte[] proavatar;

    public OrderClass() {
    }

    public OrderClass(String orderid, String orderUSid, String orderSPid, String orderproductname, String ordercategoryname, String orderproducteqty, String orderusernumber, String orderuserlocation, byte[] proavatar) {
        Orderid = orderid;
        OrderUSid = orderUSid;
        OrderSPid = orderSPid;
        Orderproductname = orderproductname;
        Ordercategoryname = ordercategoryname;
        Orderproducteqty = orderproducteqty;
        Orderusernumber = orderusernumber;
        Orderuserlocation = orderuserlocation;
        this.proavatar = proavatar;
    }

    public String getOrderid() {
        return Orderid;
    }

    public void setOrderid(String orderid) {
        Orderid = orderid;
    }
    public String getOrderUSid() {
        return OrderUSid;
    }

    public void setOrderUSid(String orderUSid) {
        OrderUSid = orderUSid;
    }

    public String getOrderSPid() {
        return OrderSPid;
    }

    public void setOrderSPid(String orderSPid) {
        OrderSPid = orderSPid;
    }

    public String getOrderproductname() {
        return Orderproductname;
    }

    public void setOrderproductname(String orderproductname) {
        Orderproductname = orderproductname;
    }

    public String getOrdercategoryname() {
        return Ordercategoryname;
    }

    public void setOrdercategoryname(String ordercategoryname) {
        Ordercategoryname = ordercategoryname;
    }

    public String getOrderproducteqty() {
        return Orderproducteqty;
    }

    public void setOrderproducteqty(String orderproducteqty) {
        Orderproducteqty = orderproducteqty;
    }

    public String getOrderusernumber() {
        return Orderusernumber;
    }

    public void setOrderusernumber(String orderusernumber) {
        Orderusernumber = orderusernumber;
    }

    public String getOrderuserlocation() {
        return Orderuserlocation;
    }

    public void setOrderuserlocation(String orderuserlocation) {
        Orderuserlocation = orderuserlocation;
    }

    public byte[] getProavatar() {
        return proavatar;
    }

    public void setProavatar(byte[] proavatar) {
        this.proavatar = proavatar;
    }
}
