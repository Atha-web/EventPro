package com.example.finalapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

public class U_C_UserHomeActivity extends AppCompatActivity {

    DrawerLayout drawerLayout;
    LinearLayout u_view,u_home,u_logout;
    ImageView menu;

    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);

        drawerLayout=findViewById(R.id.drawerLayout);
        menu=findViewById(R.id.menu);
        u_view=findViewById(R.id.userviewpage);
        u_home=findViewById(R.id.userhomepage);
        u_logout=findViewById(R.id.userlogoutpage);
        builder = new AlertDialog.Builder(this);


        RecyclerView recyclerView = findViewById(R.id.u_v_pro_rv);
        List<CategoryClass> items = new ArrayList<CategoryClass>();


        String USID = getIntent().getStringExtra("USID");

        items.add(new CategoryClass("1000","Birthday Events(1000)", R.drawable.birt));
        items.add(new CategoryClass("2000","Wedding Events(2000)",R.drawable.wedd));
        items.add(new CategoryClass("3000","Co Opreate Events(3000)",R.drawable.event));
        items.add(new CategoryClass("4000","Catering(4000)",R.drawable.cater));
        items.add(new CategoryClass("5000","Floral(5000)",R.drawable.flor));
        items.add(new CategoryClass("6000","Cars(6000)",R.drawable.wedc));
        items.add(new CategoryClass("7000","Others(7000)",R.drawable.oth));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new CategoryAdapterUser(getApplicationContext(),items));



        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opendrawer(drawerLayout);
            }
        });

        u_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recreate();
            }
        });

        u_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(U_C_UserHomeActivity.this,U_C_OrderViewActivity.class);
                 intent.putExtra("USID",USID);
                startActivity(intent);
           //     redirectActivity(UserHomeActivity.this, U_ProductSearchActivity.class);
            }
        });


        u_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                builder.setTitle(" App Logout ")
                        .setMessage(" Do you want to Logout this App ")
                        .setIcon(R.drawable.baseline_logout_24)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                redirectActivity(U_C_UserHomeActivity.this, LoginActivity.class);

                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        }).show();


            }
        });






    }


    public static void opendrawer(DrawerLayout drawerLayout){

        drawerLayout.openDrawer(GravityCompat.START);
    }

    public static void closedrawer(DrawerLayout drawerLayout) {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    public static void redirectActivity(Activity activity, Class SecondActivity){

        Intent intent = new Intent(activity,SecondActivity);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
        activity.finish();

    }

    @Override
    protected void onPause() {
        super.onPause();
        closedrawer(drawerLayout);
    }



}