package com.example.finalapp;

public class ProductClass {

    private String SPid;
    private String P_ID;
    private String productname;
    private String categoryname;
    private String productprice;
    private String productqty;
    private String productDetilas;
    private byte[] proavatar;



    public ProductClass() {
    }


    public ProductClass(String SPid, String p_ID, String productname, String productprice, String productqty, String productDetilas, byte[] proavatar) {
        this.SPid = SPid;
        P_ID = p_ID;
        this.productname = productname;
        this.productprice = productprice;
        this.productqty = productqty;
        this.productDetilas = productDetilas;
        this.proavatar = proavatar;
    }

    public ProductClass(String SPid, String productname, String categoryname, String productprice, String productDetilas, byte[] proavatar) {
        this.SPid = SPid;
        this.productname = productname;
        this.categoryname = categoryname;
        this.productprice = productprice;
        this.productDetilas = productDetilas;
        this.proavatar = proavatar;
    }



    public String getP_ID() {
        return P_ID;
    }

    public void setP_ID(String p_ID) {
        P_ID = p_ID;
    }
    public String getProductqty() {
        return productqty;
    }

    public void setProductqty(String productqty) {
        this.productqty = productqty;
    }
    public String getProductDetilas() {
        return productDetilas;
    }

    public void setProductDetilas(String productDetilas) {
        this.productDetilas = productDetilas;
    }

    public String getSPid() {
        return SPid;
    }

    public void setSPid(String SPid) {
        this.SPid = SPid;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getCategoryname() {
        return categoryname;
    }

    public void setCategoryname(String categoryname) {
        this.categoryname = categoryname;
    }

    public String getProductprice() {
        return productprice;
    }

    public void setProductprice(String productprice) {
        this.productprice = productprice;
    }

    public byte[] getProavatar() {
        return proavatar;
    }

    public void setProavatar(byte[] proavatar) {
        this.proavatar = proavatar;
    }
}
