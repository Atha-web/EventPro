package com.example.finalapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdminSPPRowViewHolder extends RecyclerView.Adapter<AdminSPPRowViewHolder.ViewHolder> {

    private ArrayList<productClass2> ProductModalArrayList;
    private Context context;
    private DBHandler dbHandler;

    public AdminSPPRowViewHolder(ArrayList<productClass2> productModalArrayList, Context context) {
        ProductModalArrayList = productModalArrayList;
        this.context = context;
    }


    @NonNull
    @Override
    public AdminSPPRowViewHolder.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sp_row2, parent, false);
        return new AdminSPPRowViewHolder.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdminSPPRowViewHolder.ViewHolder holder, int position) {

        productClass2 modal = ProductModalArrayList.get(position);//link adater to class
        byte[] image = modal.getProavatar();
        Bitmap bitmap = BitmapFactory.decodeByteArray(image,0,image.length);


        // The data taken from the class is put into variables related to the single row.using getter and settet method .

        holder.Pid.setText("Product ID : "+modal.getP_ID());
        holder.product_name.setText("Product Name : "+modal.getProductname());
        holder.category_name.setText("Cetagory Name : "+modal.getCategoryname());
        holder.product_Price.setText("Product Price : "+modal.getProductprice());
        holder.product_Details.setText("Product Details : "+modal.getProductDetilas());
        holder.product_imageView.setImageBitmap(bitmap);

        holder.Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dbHandler = new DBHandler(context);
                String Id = modal.getP_ID();

                if(dbHandler.deleteproduct2(Id)){
                    Toast.makeText(context, "Product Deleted", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(context, "Product not Deleted", Toast.LENGTH_SHORT).show();
                }


            }
        });

    }

    @Override
    public int getItemCount() {
        return ProductModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView Pid,product_name,category_name,product_Price,product_Details;
        private ImageView product_imageView;
        private Button Delete;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            Pid=itemView.findViewById(R.id.aId);
            product_name=itemView.findViewById(R.id.aproductname);
            category_name=itemView.findViewById(R.id.acategoryname);
            product_Price=itemView.findViewById(R.id.aproductprice);
            product_imageView=itemView.findViewById(R.id.aimageView);
            product_Details=itemView.findViewById(R.id.aproductdetails);
            Delete=itemView.findViewById(R.id.adelete);
        }
    }
}
