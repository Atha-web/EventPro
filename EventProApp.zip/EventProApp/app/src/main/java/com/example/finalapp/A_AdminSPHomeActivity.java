package com.example.finalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class A_AdminSPHomeActivity extends AppCompatActivity {



    private ArrayList<SPClass> SPModelArrayList;
    private DBHandler dbHandler;
    private AdminSPRowViewHolder SPRvAdapter;
    private RecyclerView SearchSPRV;


    Button logout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);

      logout=findViewById(R.id.logout);

      logout.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Intent intent = new Intent(A_AdminSPHomeActivity.this, LoginActivity.class);
              startActivity(intent);
              Toast.makeText(A_AdminSPHomeActivity.this, "Admin Logout", Toast.LENGTH_SHORT).show();
          }
      });


        SPModelArrayList = new ArrayList<>();
        dbHandler = new DBHandler(A_AdminSPHomeActivity.this);

        String type="Service_Provider";
        SPModelArrayList = dbHandler.SearchType(type);

        SPRvAdapter = new AdminSPRowViewHolder(SPModelArrayList, A_AdminSPHomeActivity.this);
        SearchSPRV = findViewById(R.id.sp_rv);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(A_AdminSPHomeActivity.this, RecyclerView.VERTICAL, false);
        SearchSPRV.setLayoutManager(linearLayoutManager);

        SearchSPRV.setAdapter(SPRvAdapter);

        if (SPModelArrayList.size() != 0) {

            Toast.makeText(A_AdminSPHomeActivity.this, "Service Providers Found", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(A_AdminSPHomeActivity.this, "Service Providers Not Found", Toast.LENGTH_SHORT).show();
           }









        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_Navigation3);

        bottomNavigationView.setSelectedItemId(R.id.SP);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                if(menuItem.getItemId()== R.id.SP){

                    return  true;

                } else if (menuItem.getItemId()== R.id.UC) {
                    Intent intent = new Intent(A_AdminSPHomeActivity.this, A_AdminUCHomeActivity.class);
                    startActivity(intent);
                    overridePendingTransition(0,0);

                }
                return false;
            }
        });

    }
}