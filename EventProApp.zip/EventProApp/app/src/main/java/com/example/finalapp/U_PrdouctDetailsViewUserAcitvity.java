package com.example.finalapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class U_PrdouctDetailsViewUserAcitvity extends AppCompatActivity {


    private TextView ViewSPID,ViewProductName,ViewCategoryName,ViewProductPrice,ViewProductDetails;
    private ImageView ViewProductImage;
    Button order,back;

    String ProductName,CategoryName,ProductPrice,ProductDetails,SPID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uprdouct_details_user_acitvity);


        ViewSPID=findViewById(R.id.vu_id);
        ViewProductName=findViewById(R.id.vu_produtname);
        ViewCategoryName=findViewById(R.id.vu_cetagoryname);
        ViewProductPrice=findViewById(R.id.vu_price);
        ViewProductDetails=findViewById(R.id.vu_details);
        ViewProductImage=findViewById(R.id.vu_image);
        order=findViewById(R.id.buttonorder1);




        SPID = getIntent().getStringExtra("SP_ID");
        ProductName = getIntent().getStringExtra("Product_Name");
        CategoryName = getIntent().getStringExtra("Category_Name");
        ProductPrice = getIntent().getStringExtra("Product_Price");
        ProductDetails = getIntent().getStringExtra("Product_Details");
        byte[] p_image = getIntent().getByteArrayExtra("Image");


        ViewSPID.setText(SPID);
        ViewProductName.setText(ProductName);
        ViewCategoryName.setText(CategoryName);
        ViewProductPrice.setText(ProductPrice);
        ViewProductDetails.setText(ProductDetails);
        Bitmap bitmap = BitmapFactory.decodeByteArray(p_image,0,p_image.length);
        ViewProductImage.setImageBitmap(bitmap);


        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(U_PrdouctDetailsViewUserAcitvity.this,U_OrderActivity.class);
                intent.putExtra("SP_ID",SPID);
                intent.putExtra("Product_Name",ProductName);
                intent.putExtra("Category_Name",CategoryName);
                intent.putExtra("Image",p_image);
                startActivity(intent);


            }
        });


    }
}