package com.example.finalapp;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class S_ViewAllProductActivity extends AppCompatActivity {


    private ArrayList<ProductClass> ProductModelArrayList;
    private DBHandler dbHandler;
    private S_ProductRowViewHolder ProductRvAdapter;
    private RecyclerView SearchProductRV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sp_view_all_product);

        ProductModelArrayList = new ArrayList<>();//array adapter object
        dbHandler = new DBHandler(S_ViewAllProductActivity.this);


        ProductModelArrayList = dbHandler.Search_Allproduct();//array adapter like to database


        ProductRvAdapter = new S_ProductRowViewHolder(ProductModelArrayList, S_ViewAllProductActivity.this);
        //array adapter details put into RowViewHolder Counstucor
        SearchProductRV = findViewById(R.id.pro_rv2);//recycleview id assign

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(S_ViewAllProductActivity.this, RecyclerView.VERTICAL, false);
        SearchProductRV.setLayoutManager(linearLayoutManager);

        SearchProductRV.setAdapter(ProductRvAdapter);//adapter details set in recycleview

        if (ProductModelArrayList.size() != 0) {

            Toast.makeText(S_ViewAllProductActivity.this, "Product  Found", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(S_ViewAllProductActivity.this, "Product Not Found", Toast.LENGTH_SHORT).show();

        }




    }
}