package com.example.finalapp;

public class productClass2 {


    private String P_ID;
    private String productname;
    private String categoryname;
    private String productprice;
    private String productqty;
    private String productDetilas;
    private byte[] proavatar;

    public productClass2() {
    }

    public productClass2(String p_ID, String productname, String categoryname, String productprice, String productqty, String productDetilas, byte[] proavatar) {
        P_ID = p_ID;
        this.productname = productname;
        this.categoryname = categoryname;
        this.productprice = productprice;
        this.productqty = productqty;
        this.productDetilas = productDetilas;
        this.proavatar = proavatar;
    }

    public String getP_ID() {
        return P_ID;
    }

    public void setP_ID(String p_ID) {
        P_ID = p_ID;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getCategoryname() {
        return categoryname;
    }

    public void setCategoryname(String categoryname) {
        this.categoryname = categoryname;
    }

    public String getProductprice() {
        return productprice;
    }

    public void setProductprice(String productprice) {
        this.productprice = productprice;
    }

    public String getProductqty() {
        return productqty;
    }

    public void setProductqty(String productqty) {
        this.productqty = productqty;
    }

    public String getProductDetilas() {
        return productDetilas;
    }

    public void setProductDetilas(String productDetilas) {
        this.productDetilas = productDetilas;
    }

    public byte[] getProavatar() {
        return proavatar;
    }

    public void setProavatar(byte[] proavatar) {
        this.proavatar = proavatar;
    }
}
