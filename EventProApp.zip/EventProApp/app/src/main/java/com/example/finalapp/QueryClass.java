package com.example.finalapp;

public class QueryClass {

    private String UID;
    private String SPID;

    private String UTEXT;

    public QueryClass() {
    }

    public QueryClass(String UID, String SPID, String UTEXT) {
        this.UID = UID;
        this.SPID = SPID;
        this.UTEXT = UTEXT;
    }

    public String getSPID() {
        return SPID;
    }

    public void setSPID(String SPID) {
        this.SPID = SPID;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public String getUTEXT() {
        return UTEXT;
    }

    public void setUTEXT(String UTEXT) {
        this.UTEXT = UTEXT;
    }
}
