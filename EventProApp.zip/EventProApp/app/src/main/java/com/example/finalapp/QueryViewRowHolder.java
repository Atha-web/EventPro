package com.example.finalapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class QueryViewRowHolder extends RecyclerView.Adapter<QueryViewRowHolder.ViewHolder> {
    /*

    1. Create a QueryClass to display related details through the RecyclerView adapter.
     It will help to get data from database and provide it to the adapter.

    2. Create a single line to show what should be shown through the adapter in the recycleView.
       edittext imagevew like that  create in single row.

    3.Assigns row IDs to variables created in the view holder.

    4.Using intent we can move the data in recyclerview to another activity.



  */
    private ArrayList<QueryClass> QueryModalArrayList;
    private Context context;

    public QueryViewRowHolder(ArrayList<QueryClass> queryModalArrayList, Context context) {
        // The constructor is used to put userinputdata or other data into the recycler thoruth adapter.
        QueryModalArrayList = queryModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //connect the sigle row to Recylcevikewadater
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.query_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        QueryClass modal = QueryModalArrayList.get(position);//link adater to class


        // The data taken from the class is put into variables related to the single row.using getter and settet method .
        holder.querySPID.setText("S_Provider ID : "+modal.getSPID());
        holder.queryUID.setText("User ID : "+modal.getUID());
        holder.queryTEXT.setText("User Query : "+modal.getUTEXT());


    }

    @Override
    public int getItemCount() {
        return QueryModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView querySPID,queryUID,queryTEXT;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            //3.Assigns single row IDs to variables created in the view holder.
            querySPID=itemView.findViewById(R.id.q_sp_id);
            queryUID=itemView.findViewById(R.id.q_user_id);
            queryTEXT=itemView.findViewById(R.id.q_user_text);

        }
    }
}
