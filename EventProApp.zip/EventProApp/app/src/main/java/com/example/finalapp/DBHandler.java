package com.example.finalapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHandler  extends SQLiteOpenHelper {


    private static final String DB_NAME = "E_H_DB";
    // below int is our database version
    private static final int DB_VERSION = 1;

    // below variable is for  table name.
    private static final String Register_Table = "Register_Table";
    private static final String Product_Table = "Product_Table";
    private static final String Order_Table = "Order_Table";
    private static final String Query_Table = "Query_Table";
    private static final String Confirm_Table = "Confirm_Table";

    // below variable is for Register Table  column.
    private static final String R_userID = "R_userID";
    private static final String R_password = "R_password";
    private static final String R_userType = "R_userType";
    private static final String R_userImage = "R_userImage";
    private static final String R_phoneNumber = "R_phoneNumber";
    private static final String R_emailID = "R_emailID";


    // below variable is for Product Table  column.
    private static final String P_Se_Provi_ID = "P_Se_Provi_ID";
    private static final String P_Product_ID = "P_Product_ID";
    private static final String P_Product_Name = "P_Product_Name";
    private static final String P_Cetagory_ID = "P_Cetagory_ID";
    private static final String P_Cetagory_Name = "P_Cetagory_Name";
    private static final String P_Product_Price = "P_Product_Price";
    private static final String P_Product_QTY = "P_Product_QTY";
    private static final String P_Product_Details = "P_Product_Details";
    private static final String P_ImageID = "P_ImageID";



    // below variable is for Order Table  column.
    private static final String O_Oder_ID = "O_Oder_ID";
    private static final String O_User_ID = "O_User_ID";
    private static final String O_Se_Provi_ID = "O_Se_Provi_ID";
    private static final String O_Product_Name = "O_Product_Name";
    private static final String O_Cetagory_Name = "O_Cetagory_Name";
    private static final String O_Product_QTY = "O_Product_QTY";
    private static final String O_PhoneNumber = "O_PhoneNumber";
    private static final String O_Location = "O_Location";
    private static final String O_ImageID = "O_ImageID";

    // below variable is for Query Table  column.
    private static final String Q_Se_Provi_ID = "Q_Se_Provi_ID";
    private static final String Q_User_ID = "Q_User_ID";
    private static final String Q_User_Text = "Q_User_Text";

    // below variable is for Confirm Table  column.
    private static final String SP_ID = "SP_ID";
    private static final String U_ID = "U_ID";
    private static final String O_ID = "O_ID";
    private static final String Message = "Message";



    private byte[] imagetypes;//for image



    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String query = "CREATE TABLE " + Register_Table + " ("
                + R_userID + " TEXT PRIMARY KEY, "
                + R_password + " TEXT,"
                + R_userType + " TEXT,"
                + R_phoneNumber + " TEXT,"
                + R_emailID + " TEXT,"
                + R_userImage + " BLOB)";

        String query1 = "CREATE TABLE " + Product_Table + " ("
                + P_Se_Provi_ID + " TEXT , "
                + P_Product_ID + " TEXT PRIMARY KEY,"
                + P_Product_Name + " TEXT,"
                + P_Cetagory_ID + " TEXT,"
                + P_Cetagory_Name + " TEXT,"
                + P_Product_Price + " TEXT,"
                + P_Product_QTY + " TEXT,"
                + P_Product_Details + " TEXT,"
                + P_ImageID + " BLOB)";
        String query2 = "CREATE TABLE " + Order_Table + " ("
                + O_Oder_ID + " TEXT PRIMARY KEY, "
                + O_User_ID + " TEXT , "
                + O_Se_Provi_ID + " TEXT , "
                + O_Product_Name + " TEXT ,"
                + O_Cetagory_Name + " TEXT,"
                + O_Product_QTY + " TEXT,"
                + O_PhoneNumber + " TEXT,"
                + O_Location + " TEXT,"
                + O_ImageID + " BLOB)";


        String query3 = "CREATE TABLE " + Query_Table + " ("
                + Q_User_ID + " TEXT , "
                + Q_Se_Provi_ID + " TEXT , "
                + Q_User_Text + " TEXT PRIMARY KEY)";

        String query4 = "CREATE TABLE " + Confirm_Table + " ("
                + SP_ID + " TEXT , "
                + U_ID + " TEXT , "
                + O_ID + " TEXT PRIMARY KEY, "
                + Message + " TEXT )";


        // method to execute above sql query

        db.execSQL(query);
        db.execSQL(query1);
        db.execSQL(query2);
        db.execSQL(query3);
        db.execSQL(query4);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + Register_Table);//drop the table
        db.execSQL("DROP TABLE IF EXISTS " + Product_Table);
        db.execSQL("DROP TABLE IF EXISTS " + Order_Table);
        db.execSQL("DROP TABLE IF EXISTS " + Query_Table);
        db.execSQL("DROP TABLE IF EXISTS " + Confirm_Table);

    }

    public boolean addNewUser(String userName, String password, String userType, String phoneNumber, String email, byte[] byteSSP) {

// on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are creating a
        // variable for content values.
        ContentValues values = new ContentValues();
        imagetypes =byteSSP;//   * The image id cannot be used to get and enter other variable data as usual.
        //  it is use for byte[] array type varible and Blob data type use.

        // on below line we are passing all values
        // along with its key and value pair.
        values.put(R_userID, userName);
        values.put(R_password, password);
        values.put(R_userType, userType);
        values.put(R_phoneNumber, phoneNumber);
        values.put(R_emailID, email);
        values.put(R_userImage, imagetypes);

        // after adding all values we are passing
        // content values to our table.
        db.insert(Register_Table, null, values);

        // at last we are closing our
        // database after adding database.
        return true;



    }


    public ArrayList<S_User_Class> ValidLogin(String UserID, String Password) {

        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<S_User_Class> userList = new ArrayList<S_User_Class>();

        try
        {
            Cursor cursor=db.rawQuery("select * from Register_Table where R_userID='"+UserID+"'and R_password='"+Password+"'",null);
            if(cursor.moveToFirst())//T
            {
                do{
                    S_User_Class user = new S_User_Class();
                    user.setUserId(cursor.getString(0));//U001
                    user.setPassword(cursor.getString(1));//111
                    user.setUserType(cursor.getString(2));//Service_Provider or User
                    userList.add(user);

                }while (cursor.moveToNext());//F
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return  userList;//details return
    }

    public boolean addNewProduct(String s_p_id, String s_p_productId, String s_p_productName, String s_p_categoryId, String s_p_categoryName, String s_p_productPrice, String s_p_productQty, String s_p_productAbout, byte[] byteSSP) {

        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();
        // on below line we are creating a
        // variable for content values.
        ContentValues values = new ContentValues();
        imagetypes =byteSSP;//   * The image id cannot be used to get and enter other variable data as usual.
        //  it is use for byte[] array type varible and Blob data type use.

        // on below line we are passing all values
        // along with its key and value pair.
        values.put(P_Se_Provi_ID, s_p_id);
        values.put(P_Product_ID, s_p_productId);
        values.put(P_Product_Name, s_p_productName);
        values.put(P_Cetagory_ID, s_p_categoryId);
        values.put(P_Cetagory_Name, s_p_categoryName);
        values.put(P_Product_Price, s_p_productPrice);
        values.put(P_Product_QTY, s_p_productQty);
        values.put(P_Product_Details, s_p_productAbout);
        values.put(P_ImageID, imagetypes);

        // after adding all values we are passing
        // content values to our table.
        db.insert(Product_Table, null, values);


        return true;



    }

    public ArrayList<ProductClass> UpdateSearchProduct(String spid) {

        SQLiteDatabase db = this.getReadableDatabase();

        ArrayList<ProductClass> Product_list = new ArrayList<ProductClass>();


        try{
            Cursor cursor = db.rawQuery("Select * from Product_Table where P_Se_Provi_ID='" + spid + "' ", null);

            if (cursor.moveToFirst()) {
                do {
                    String Sp_id = cursor.getString(0);
                    String P_id = cursor.getString(1);
                    String product_name = cursor.getString(2);
                    String prodcut_Qty = cursor.getString(6);
                    String prodcut_Price = cursor.getString(5);
                    String prodcut_Details = cursor.getString(7);
                    imagetypes = cursor.getBlob(8);

                    ProductClass ProductClass = new ProductClass();
                    ProductClass.setSPid(Sp_id);
                    ProductClass.setP_ID(P_id);
                    ProductClass.setProductname(product_name);
                    ProductClass.setProductqty(prodcut_Qty);
                    ProductClass.setProductprice(prodcut_Price);
                    ProductClass.setProductDetilas(prodcut_Details);
                    ProductClass.setProavatar(imagetypes);
                    Product_list.add(ProductClass);

                } while (cursor.moveToNext());
            }

        }catch(Exception ex){
            ex.printStackTrace();
        }

        return Product_list;


    }

    public ArrayList<ProductClass> Search_Allproduct() {

        // on below line we are creating a
        // database for reading our database.
        SQLiteDatabase db = this.getReadableDatabase();

        // on below line we are creating a cursor with query to
        // read data from database.
        Cursor cursorProducts
                = db.rawQuery("SELECT * FROM " + Product_Table, null);

        // on below line we are creating a new array list.
        ArrayList<ProductClass> ProductModalArrayList
                = new ArrayList<>();


        // moving our cursor to first position.
        if (cursorProducts.moveToFirst()) {
            do {
                // on below line we are adding the data from
                // cursor to our array list.
                ProductModalArrayList.add(new ProductClass(
                        cursorProducts.getString(0),
                        cursorProducts.getString(2),
                        cursorProducts.getString(4),
                        cursorProducts.getString(5),
                        cursorProducts.getString(7),
                        cursorProducts.getBlob(8)));
            } while (cursorProducts.moveToNext());
            // moving our cursor to next.
        }


        // at last closing our cursor
        // and returning our array list.
        cursorProducts.close();
        return ProductModalArrayList;



    }

    public ArrayList<ProductClass> SearchProduct2(String searchProduct) {

        SQLiteDatabase db = this.getReadableDatabase();

        ArrayList<ProductClass> Product_list = new ArrayList<ProductClass>();


        try {
            Cursor cursor = db.rawQuery("Select * from Product_Table where P_Product_Name='" + searchProduct + "' ", null);

            if (cursor.moveToFirst()) {
                do {
                    String Sp_id = cursor.getString(0);//sp id
                    String product_name = cursor.getString(2);//product name
                    String category_name = cursor.getString(4);//category name
                    String prodcut_Price = cursor.getString(5);//productrice
                    String prodcut_Details = cursor.getString(7);//product details
                    imagetypes = cursor.getBlob(8);//image id

                    ProductClass ProductClass = new ProductClass();
                    ProductClass.setSPid(Sp_id);//set the database values in class
                    ProductClass.setProductname(product_name);
                    ProductClass.setCategoryname(category_name);
                    ProductClass.setProductprice(prodcut_Price);
                    ProductClass.setProductDetilas(prodcut_Details);
                    ProductClass.setProavatar(imagetypes);
                    Product_list.add(ProductClass);

                } while (cursor.moveToNext());
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return Product_list;



    }

    public boolean deleteProduct(String u_pid) {


        // on below line we are creating
        // a variable to write our database.

        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are calling a method to delete our
        // Product and we are comparing it with our course name.
        db.delete(Product_Table, "P_Product_ID=?", new String[]{u_pid});
        db.close();


        return true;
    }

    public boolean UpdateProduct(String u_pid, String u_prductname, String u_prductprice, String u_prductqty, String u_prductdetail, byte[] u_image) {

        // calling a method to get writable database.
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        imagetypes =u_image;

        // on below line we are passing all values
        // along with its key and value pair.
        values.put(P_Product_Name, u_prductname);
        values.put(P_Product_Price, u_prductprice);
        values.put(P_Product_QTY, u_prductqty);
        values.put(P_Product_Details, u_prductdetail);
        values.put(P_ImageID, imagetypes);

        // on below line we are calling a update method to update our database and passing our values.
        // and we are comparing it with name of our course which is stored in original name variable.
        db.update(Product_Table, values, "P_Product_ID=?", new String[]{u_pid});
        db.close();

        return true;



    }

    public ArrayList<ProductClass> Category_Allproduct(String c_category_id) {

        SQLiteDatabase db = this.getReadableDatabase();

        ArrayList<ProductClass> Product_list = new ArrayList<ProductClass>();


        try{
            Cursor cursor = db.rawQuery("Select * from Product_Table where P_Cetagory_ID='" + c_category_id + "' ", null);

            if (cursor.moveToFirst()) {
                do {
                    String Sp_id = cursor.getString(0);
                    String P_id = cursor.getString(1);
                    String product_name = cursor.getString(2);
                    String Category_name = cursor.getString(4);
                    String prodcut_Price = cursor.getString(5);
                    String prodcut_Details = cursor.getString(7);
                    imagetypes = cursor.getBlob(8);

                    ProductClass ProductClass = new ProductClass();
                    ProductClass.setSPid(Sp_id);
                    ProductClass.setP_ID(P_id);
                    ProductClass.setProductname(product_name);
                    ProductClass.setCategoryname(Category_name);
                    ProductClass.setProductprice(prodcut_Price);
                    ProductClass.setProductDetilas(prodcut_Details);
                    ProductClass.setProavatar(imagetypes);
                    Product_list.add(ProductClass);

                } while (cursor.moveToNext());
            }

        }catch(Exception ex){
            ex.printStackTrace();
        }

        return Product_list;

    }

    public boolean AddOrder(String or_id, String or_usid, String or_spid, String or_productName, String or_categoryName, String or_qty, String or_phoneNumber, String or_location, byte[] p_image) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        imagetypes =p_image;


        values.put(O_Oder_ID, or_id);
        values.put(O_User_ID, or_usid);
        values.put(O_Se_Provi_ID, or_spid);
        values.put(O_Product_Name, or_productName);
        values.put(O_Cetagory_Name, or_categoryName);
        values.put(O_Product_QTY, or_qty);
        values.put(O_PhoneNumber, or_phoneNumber);
        values.put(O_Location, or_location);
        values.put(O_ImageID, imagetypes);


        db.insert(Order_Table, null, values);

        return true;

    }

    public ArrayList<OrderClass> SearchOder(String usid) {

        SQLiteDatabase db = this.getReadableDatabase();

        ArrayList<OrderClass> Order_list = new ArrayList<OrderClass>();


        try{
            Cursor cursor = db.rawQuery("Select * from Order_Table where O_User_ID='" + usid + "' ", null);

            if (cursor.moveToFirst()) {
                do {
                    String or_id = cursor.getString(0);
                    String us_id = cursor.getString(1);
                    String Sp_id = cursor.getString(2);
                    String product_name = cursor.getString(3);
                    String category_name = cursor.getString(4);
                    String prodcut_QTY = cursor.getString(5);
                    String PhoneNumber = cursor.getString(6);
                    String Location = cursor.getString(7);
                    imagetypes = cursor.getBlob(8);

                    OrderClass orderClass = new OrderClass();
                    orderClass.setOrderid(or_id);
                    orderClass.setOrderUSid(us_id);
                    orderClass.setOrderSPid(Sp_id);
                    orderClass.setOrderproductname(product_name);
                    orderClass.setOrdercategoryname(category_name);
                    orderClass.setOrderproducteqty(prodcut_QTY);
                    orderClass.setOrderusernumber(PhoneNumber);
                    orderClass.setOrderuserlocation(Location);
                    orderClass.setProavatar(imagetypes);
                    Order_list.add(orderClass);

                } while (cursor.moveToNext());
            }

        }catch(Exception ex){
            ex.printStackTrace();
        }

        return Order_list;

    }


    public ArrayList<OrderClass> SearchOder2(String spid) {

        SQLiteDatabase db = this.getReadableDatabase();

        ArrayList<OrderClass> Order_list = new ArrayList<OrderClass>();


        try{
            Cursor cursor = db.rawQuery("Select * from Order_Table where O_Se_Provi_ID='" + spid + "' ", null);

            if (cursor.moveToFirst()) {
                do {
                    String or_id = cursor.getString(0);
                    String us_id = cursor.getString(1);
                    String Sp_id = cursor.getString(2);
                    String product_name = cursor.getString(3);
                    String category_name = cursor.getString(4);
                    String prodcut_QTY = cursor.getString(5);
                    String PhoneNumber = cursor.getString(6);
                    String Location = cursor.getString(7);
                    imagetypes = cursor.getBlob(8);

                    OrderClass orderClass = new OrderClass();
                    orderClass.setOrderid(or_id);
                    orderClass.setOrderUSid(us_id);
                    orderClass.setOrderSPid(Sp_id);
                    orderClass.setOrderproductname(product_name);
                    orderClass.setOrdercategoryname(category_name);
                    orderClass.setOrderproducteqty(prodcut_QTY);
                    orderClass.setOrderusernumber(PhoneNumber);
                    orderClass.setOrderuserlocation(Location);
                    orderClass.setProavatar(imagetypes);
                    Order_list.add(orderClass);

                } while (cursor.moveToNext());
            }

        }catch(Exception ex){
            ex.printStackTrace();
        }

        return Order_list;



    }

    public void addConfirm(String sid, String oid, String uid, String message) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();


        values.put(SP_ID, sid);
        values.put(U_ID, uid);
        values.put(O_ID, oid);
        values.put(Message, message);

        db.insert(Confirm_Table, null, values);


    }

    public ArrayList<ConfrimClass> validOrder(String id) {

        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<ConfrimClass> message = new ArrayList<ConfrimClass>();

        try
        {
            Cursor cursor=db.rawQuery("select * from Confirm_Table where O_ID='"+id+"'",null);
            if(cursor.moveToFirst())//T
            {
                do{
                    ConfrimClass confirm = new ConfrimClass();
                    confirm.setOderId(cursor.getString(2));//oder id
                    confirm.setMessage(cursor.getString(3));//message

                    message.add(confirm);

                }while (cursor.moveToNext());//F
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return  message;//details return
    }


    public boolean addQuery(String query_userid, String query_spid, String query_text) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();



        values.put(Q_User_ID, query_userid);
        values.put(Q_Se_Provi_ID, query_spid);
        values.put(Q_User_Text, query_text);


        db.insert(Query_Table, null, values);

        return true;
    }

    public ArrayList<QueryClass> SearchQuery(String usid) {

        SQLiteDatabase db = this.getReadableDatabase();

        ArrayList<QueryClass> Query_list = new ArrayList<QueryClass>();



        try{
            Cursor cursor = db.rawQuery("Select * from Query_Table where Q_User_ID='" + usid + "' ", null);

            if (cursor.moveToFirst()) {
                do {
                    String Sp_id = cursor.getString(0);
                    String Us_id = cursor.getString(1);
                    String Us_text = cursor.getString(2);


                    QueryClass queryClass = new QueryClass();
                    queryClass.setSPID(Sp_id);
                    queryClass.setUID(Us_id);
                    queryClass.setUTEXT(Us_text);
                    Query_list.add(queryClass);

                } while (cursor.moveToNext());
            }

        }catch(Exception ex){
            ex.printStackTrace();
        }

        return Query_list;




    }

    public ArrayList<QueryClass> SearchQuery2(String spid) {


        SQLiteDatabase db = this.getReadableDatabase();

        ArrayList<QueryClass> Query_list = new ArrayList<QueryClass>();

        try{
            Cursor cursor = db.rawQuery("Select * from Query_Table where Q_Se_Provi_ID='" + spid + "' ", null);

            if (cursor.moveToFirst()) {
                do {
                    String Sp_id = cursor.getString(0);
                    String Us_id = cursor.getString(1);
                    String Us_text = cursor.getString(2);


                    QueryClass queryClass = new QueryClass();
                    queryClass.setSPID(Sp_id);
                    queryClass.setUID(Us_id);
                    queryClass.setUTEXT(Us_text);

                    Query_list.add(queryClass);

                } while (cursor.moveToNext());
            }

        }catch(Exception ex){
            ex.printStackTrace();
        }

        return Query_list;



    }

    public ArrayList<SPClass> SearchType(String type) {


        SQLiteDatabase db = this.getReadableDatabase();

        ArrayList<SPClass> user_list = new ArrayList<SPClass>();


        try{
            Cursor cursor = db.rawQuery("Select * from Register_Table where R_userType='" + type + "' ", null);

            if (cursor.moveToFirst()) {
                do {


                    String spid = cursor.getString(0);
                    String sptype = cursor.getString(2);
                    String Spnumber = cursor.getString(3);
                    String spemail = cursor.getString(4);
                    imagetypes = cursor.getBlob(5);

                    SPClass userClass = new SPClass();
                    userClass.setSPid(spid);
                    userClass.setSPusertype(sptype);
                    userClass.setSPphonenumber(Spnumber);
                    userClass.setSPemail(spemail);
                    userClass.setProavatar(imagetypes);
                    user_list.add(userClass);

                } while (cursor.moveToNext());
            }

        }catch(Exception ex){
            ex.printStackTrace();
        }

        return user_list;




    }

    public boolean deleteSP(String id) {

        // on below line we are creating
        // a variable to write our database.

        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are calling a method to delete our
        // Product and we are comparing it with our course name.
        db.delete(Register_Table, "R_userID=?", new String[]{id});
        db.close();

        return true;

    }

    public ArrayList<productClass2> SearchProduct3(String id) {

        SQLiteDatabase db = this.getReadableDatabase();

        ArrayList<productClass2> Product_list = new ArrayList<productClass2>();


        try {
            Cursor cursor = db.rawQuery("Select * from Product_Table where P_Se_Provi_ID='" + id + "' ", null);

            if (cursor.moveToFirst()) {
                do {
                    String pid = cursor.getString(1);//id
                    String product_name = cursor.getString(2);//product name
                    String category_name = cursor.getString(4);//category name
                    String prodcut_Price = cursor.getString(5);//productrice
                    String prodcut_Details = cursor.getString(7);//product details
                    imagetypes = cursor.getBlob(8);//image id

                    productClass2 ProductClass = new productClass2();
                    ProductClass.setP_ID(pid);//set the database values in class
                    ProductClass.setProductname(product_name);
                    ProductClass.setCategoryname(category_name);
                    ProductClass.setProductprice(prodcut_Price);
                    ProductClass.setProductDetilas(prodcut_Details);
                    ProductClass.setProavatar(imagetypes);
                    Product_list.add(ProductClass);

                } while (cursor.moveToNext());
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return Product_list;



    }

    public boolean deleteproduct2(String id) {

        // on below line we are creating
        // a variable to write our database.

        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are calling a method to delete our
        // Product and we are comparing it with our course name.
        db.delete(Product_Table, "P_Product_ID=?", new String[]{id});
        db.close();

        return true;

    }


    public ArrayList<UCClass> SearchType1(String type) {

        SQLiteDatabase db = this.getReadableDatabase();

        ArrayList<UCClass> user_list = new ArrayList<UCClass>();


        try{
            Cursor cursor = db.rawQuery("Select * from Register_Table where R_userType='" + type + "' ", null);

            if (cursor.moveToFirst()) {
                do {


                    String spid = cursor.getString(0);
                    String sptype = cursor.getString(2);
                    String Spnumber = cursor.getString(3);
                    String spemail = cursor.getString(4);
                    imagetypes = cursor.getBlob(5);

                    UCClass userClass = new UCClass();
                    userClass.setUCid(spid);
                    userClass.setUCusertype(sptype);
                    userClass.setUCphonenumber(Spnumber);
                    userClass.setUCemail(spemail);
                    userClass.setProavatar(imagetypes);
                    user_list.add(userClass);

                } while (cursor.moveToNext());
            }

        }catch(Exception ex){
            ex.printStackTrace();
        }

        return user_list;
    }

    public boolean deleteUC(String id) {

        // on below line we are creating
        // a variable to write our database.

        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are calling a method to delete our
        // Product and we are comparing it with our course name.
        db.delete(Register_Table, "R_userID=?", new String[]{id});
        db.close();

        return true;
    }

    public void deleteSpProduct(String id) {


        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are calling a method to delete our
        // Product and we are comparing it with our course name.
        db.delete(Product_Table, "P_Se_Provi_ID=?", new String[]{id});
        db.close();


    }



}
