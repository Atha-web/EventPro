package com.example.finalapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class S_ProductDetailsViewActivity extends AppCompatActivity {


   private TextView ViewSPID,ViewProductName,ViewCategoryName,ViewProductPrice,ViewProductDetails;
   private ImageView ViewProductImage;
   private Button back;

    String ProductName,CategoryName,ProductPrice,ProductDetails,SPID;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details_view);

        ViewSPID=findViewById(R.id.v_id);
        ViewProductName=findViewById(R.id.v_produtname);
        ViewCategoryName=findViewById(R.id.v_cetagoryname);
        ViewProductPrice=findViewById(R.id.v_price);
        ViewProductDetails=findViewById(R.id.v_details);
        ViewProductImage=findViewById(R.id.v_image);


//After taking the details of recycling through intent, it is assigned to another variable using id.
        SPID = getIntent().getStringExtra("SP_ID");
        ProductName = getIntent().getStringExtra("Product_Name");
        CategoryName = getIntent().getStringExtra("Category_Name");
        ProductPrice = getIntent().getStringExtra("Product_Price");
        ProductDetails = getIntent().getStringExtra("Product_Details");
        byte[] p_image = getIntent().getByteArrayExtra("Image");

        //that varible put into edittext and image view reprsesnet ids

        ViewSPID.setText(SPID);
        ViewProductName.setText(ProductName);
        ViewCategoryName.setText(CategoryName);
        ViewProductPrice.setText(ProductPrice);
        ViewProductDetails.setText(ProductDetails);
        Bitmap bitmap = BitmapFactory.decodeByteArray(p_image,0,p_image.length);
        ViewProductImage.setImageBitmap(bitmap);





    }
}