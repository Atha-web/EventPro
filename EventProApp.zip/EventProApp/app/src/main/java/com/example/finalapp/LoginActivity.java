package com.example.finalapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class LoginActivity extends AppCompatActivity {

    private  EditText lo_UserID,lo_Password;
    private  Button login_Button;

    private ProgressBar progressBar;
    AlertDialog.Builder builder;
    int counter=0;
    private DBHandler dbHandler;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHandler = new DBHandler(LoginActivity.this);
        builder = new AlertDialog.Builder(this);

        lo_UserID=findViewById(R.id.editTextloginuserid);
        lo_Password=findViewById(R.id.editTextloginuserpassword);
        login_Button=findViewById(R.id.buttonloginbutton);
        progressBar=findViewById(R.id.progressBar);

        Timer timer = new Timer();


        login_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(lo_UserID.getText().toString().isEmpty()|| lo_Password.getText().toString().isEmpty()){

                    Toast.makeText(LoginActivity.this, "Filed cant be blank", Toast.LENGTH_SHORT).show();

                }
                else{

                    String Id=lo_UserID.getText().toString();
                    String pass=lo_Password.getText().toString();


                    ArrayList<S_User_Class> userDetails =
                            dbHandler.ValidLogin(lo_UserID.getText().toString(),
                                    lo_Password.getText().toString());



                    if (userDetails.size() != 0) {//check the details have or not ,if have data we can continue

                        S_User_Class user = userDetails.get(0);
                        String UserType = user.getUserType();//Service_Provider



                        if (UserType.equals("Service_Provider")) {


                            progressBar.setVisibility(View.VISIBLE);//progress bar visible


                            TimerTask timerTask = new TimerTask() {
                                @Override
                                public void run() {
                                    counter++;                       //icncrease the counter varible on by one to 150
                                    progressBar.setProgress(counter); //put counter varible in the progress .
                                    // then progress bar also run like incress counter varible

                                    if(counter==300){//if counter varivbvle close to 150 timer close()
                                        timer.cancel();

                                    }
                                }

                            };

                            Toast.makeText(getApplicationContext(), "User found" +
                                    UserType, Toast.LENGTH_LONG).show();

                            Intent intentRegister =
                                    new Intent(LoginActivity.this, S_P_ProviderHomeAvtivtiy.class);
                            intentRegister.putExtra("SPID",Id);
                            startActivity(intentRegister);


                            timer.schedule(timerTask,100,300);

                        }
                        else {

                            progressBar.setVisibility(View.VISIBLE);
                            TimerTask timerTask = new TimerTask() {
                                @Override
                                public void run() {
                                    counter++;
                                    progressBar.setProgress(counter);

                                    if(counter==300){
                                        timer.cancel();

                                    }
                                }
                            };

                            Toast.makeText(getApplicationContext(), "User found" +
                                    UserType, Toast.LENGTH_LONG).show();

                            Intent intentRegister = new Intent(LoginActivity.this, U_C_UserHomeActivity.class);
                            intentRegister.putExtra("USID",Id);
                            startActivity(intentRegister);

                            timer.schedule(timerTask,100,300);

                        }
                    }
                    else

                    {

                        if(Id.equals("admin") && pass.equals("123456")){


                            progressBar.setVisibility(View.VISIBLE);//progress bar visible


                            TimerTask timerTask = new TimerTask() {
                                @Override
                                public void run() {
                                    counter++;                       //icncrease the counter varible on by one to 150
                                    progressBar.setProgress(counter); //put counter varible in the progress .
                                    // then progress bar also run like incress counter varible

                                    if(counter==300){//if counter varivbvle close to 150 timer close()
                                        timer.cancel();

                                    }
                                }

                            };


                            Intent intentRegister =
                                    new Intent(LoginActivity.this, A_AdminSPHomeActivity.class);
                            startActivity(intentRegister);

                            Toast.makeText(LoginActivity.this, "Admin Login Valid", Toast.LENGTH_SHORT).show();
                            timer.schedule(timerTask,100,300);
                        }
                        else {


                            builder.setTitle(" Invalid User!")
                                    .setMessage("Please Check Your Username and Password ")
                                    .setIcon(R.drawable.baseline_info_24)
                                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int i) {
                                            dialog.cancel();
                                        }
                                    }).show();

                        }


                    }








                }



            }
        });










    }


}