package com.example.finalapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class S_ViewCatProductActivity extends AppCompatActivity {


    private ArrayList<ProductClass> ProductModelArrayList;
    private DBHandler dbHandler;
    private S_ProductRowViewHolder ProductRvAdapter;
    private RecyclerView SearchProductRV;
    String c_category_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sview_cat_product2);

        c_category_id = getIntent().getStringExtra("categoryID");

        ProductModelArrayList = new ArrayList<>();
        dbHandler = new DBHandler(S_ViewCatProductActivity.this);

        ProductModelArrayList = dbHandler.Category_Allproduct(c_category_id);



        ProductRvAdapter = new S_ProductRowViewHolder(ProductModelArrayList, S_ViewCatProductActivity.this);
        SearchProductRV = findViewById(R.id.cat_pro_rv00);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(S_ViewCatProductActivity.this, RecyclerView.VERTICAL, false);
        SearchProductRV.setLayoutManager(linearLayoutManager);

        SearchProductRV.setAdapter(ProductRvAdapter);

        if (ProductModelArrayList.size() != 0) {

            Toast.makeText(S_ViewCatProductActivity.this, "Product  Found", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(S_ViewCatProductActivity.this, "Product Not Found", Toast.LENGTH_SHORT).show();

        }



    }
}