package com.example.finalapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

public class U_ConfirmMessageActivity extends AppCompatActivity {

    DBHandler dbHandler;
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uconfirm_message);

        builder = new AlertDialog.Builder(this);
        dbHandler= new DBHandler(U_ConfirmMessageActivity.this);

        String USID = getIntent().getStringExtra("USID");
        String OID = getIntent().getStringExtra("O_ID");
        String PN = getIntent().getStringExtra("Product_Name");

        ArrayList<ConfrimClass> orderDetails =
                dbHandler.validOrder(USID);

        if (orderDetails.size() != 0) {//check the details have or not ,if have data we can continue

            ConfrimClass order = orderDetails.get(0);
            String message = order.getMessage();

            if (message.equals("Order has been Confirmed")) {

                builder.setTitle("Order Confirmation")
                        .setMessage(" Order has been Confirmed")
                        .setMessage("Oder ID : "+OID)
                        .setMessage("Product Name : "+PN)
                        .setIcon(R.drawable.baseline_message_24)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                             //   redirectActivity(S_P_ProviderHomeAvtivtiy.this, LoginActivity.class);
                                Intent intent = new Intent(U_ConfirmMessageActivity.this,U_C_OrderViewActivity.class);
                                intent.putExtra("USID",USID);
                                startActivity(intent);

                            }
                        })
                        .show();

            }
            else if (message.equals("Order has been Canceled")) {

                builder.setTitle("Order Confirmation")
                        .setMessage(" Order has been Canceled")
                        .setMessage("Oder ID : "+OID)
                        .setMessage("Product Name : "+PN)
                        .setIcon(R.drawable.baseline_message_24)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                //   redirectActivity(S_P_ProviderHomeAvtivtiy.this, LoginActivity.class);
                                Intent intent = new Intent(U_ConfirmMessageActivity.this,U_C_OrderViewActivity.class);
                                intent.putExtra("USID",USID);
                                startActivity(intent);

                            }
                        })
                        .show();

            }else{

                builder.setTitle("Order Confirmation")
                        .setMessage(" Order Pending.......")
                        .setMessage("Oder ID : "+OID)
                        .setMessage("Product Name : "+PN)
                        .setIcon(R.drawable.baseline_message_24)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                //   redirectActivity(S_P_ProviderHomeAvtivtiy.this, LoginActivity.class);
                                Intent intent = new Intent(U_ConfirmMessageActivity.this,U_C_OrderViewActivity.class);
                                intent.putExtra("USID",USID);
                                startActivity(intent);

                            }
                        })
                        .show();

            }


        }




        }


}