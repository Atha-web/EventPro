package com.example.finalapp;

public class UCClass {


    private String UCid;
    private String UCusertype;
    private String UCphonenumber;
    private String UCemail;
    private byte[] proavatar;

    public UCClass() {
    }

    public UCClass(String UCid, String UCusertype, String UCphonenumber, String UCemail, byte[] proavatar) {
        this.UCid = UCid;
        this.UCusertype = UCusertype;
        this.UCphonenumber = UCphonenumber;
        this.UCemail = UCemail;
        this.proavatar = proavatar;
    }


    public String getUCid() {
        return UCid;
    }

    public void setUCid(String UCid) {
        this.UCid = UCid;
    }

    public String getUCusertype() {
        return UCusertype;
    }

    public void setUCusertype(String UCusertype) {
        this.UCusertype = UCusertype;
    }

    public String getUCphonenumber() {
        return UCphonenumber;
    }

    public void setUCphonenumber(String UCphonenumber) {
        this.UCphonenumber = UCphonenumber;
    }

    public String getUCemail() {
        return UCemail;
    }

    public void setUCemail(String UCemail) {
        this.UCemail = UCemail;
    }

    public byte[] getProavatar() {
        return proavatar;
    }

    public void setProavatar(byte[] proavatar) {
        this.proavatar = proavatar;
    }



}
