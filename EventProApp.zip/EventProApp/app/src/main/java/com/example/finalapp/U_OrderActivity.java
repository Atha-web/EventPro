package com.example.finalapp;

import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class U_OrderActivity extends AppCompatActivity {

    private EditText Order_SPID,Order_ProductName,Order_CategoryName
            ,Order_QTY,Order_PhoneNumber,Order_Location,order_id,order_Usid;
    private Button Order_Add,back;

    private ImageView order_imageView;
    AlertDialog.Builder builder;
    private String Or_SPID,Or_ProductName,Or_CategoryName;
    String or_Qty,or_PhoneNumber,or_Location,or_id,or_usid;
    private DBHandler dbHandler ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        dbHandler = new DBHandler(U_OrderActivity.this);
        builder = new AlertDialog.Builder(this);

        order_imageView=findViewById(R.id.orderimageView);
        Order_SPID=findViewById(R.id.order_spid);
        Order_ProductName=findViewById(R.id.order_productname);
        Order_CategoryName=findViewById(R.id.order_cetagoryname);
        Order_QTY=findViewById(R.id.order_qty);
        Order_PhoneNumber=findViewById(R.id.order_phonenumber);
        Order_Location=findViewById(R.id.order_location);
        order_id=findViewById(R.id.order_id);
        order_Usid=findViewById(R.id.order_usid);
        Order_Add=findViewById(R.id.buttonorder);



        Or_SPID = getIntent().getStringExtra("SP_ID");
        Or_ProductName = getIntent().getStringExtra("Product_Name");
        Or_CategoryName = getIntent().getStringExtra("Category_Name");
        byte[] p_image = getIntent().getByteArrayExtra("Image");

        //random number Gen.....

        Random random = new Random();
        int val = random.nextInt(1000);
        order_id.setText("Oder ID : " + Integer.toString(val));




        Order_SPID.setText(Or_SPID);
        Order_ProductName.setText(Or_ProductName);
        Order_CategoryName.setText(Or_CategoryName);
        Bitmap bitmap = BitmapFactory.decodeByteArray(p_image,0,p_image.length);
        order_imageView.setImageBitmap(bitmap);



        Order_Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(Order_SPID.getText().toString().isEmpty()||Order_ProductName.getText().toString().isEmpty()
                ||Order_CategoryName.getText().toString().isEmpty()||Order_QTY.getText().toString().isEmpty()
                ||Order_PhoneNumber.getText().toString().isEmpty()||Order_Location.getText().toString().isEmpty()){
                    Toast.makeText(U_OrderActivity.this, "Feild Cant be blank !!!!!", Toast.LENGTH_SHORT).show();
                }
                else{

                    or_Qty=Order_QTY.getText().toString();
                    or_PhoneNumber=Order_PhoneNumber.getText().toString();
                    or_Location=Order_Location.getText().toString();
                    or_id =order_id.getText().toString();
                    or_usid =order_Usid.getText().toString();

                    if(dbHandler.AddOrder(or_id,or_usid,Or_SPID,Or_ProductName,Or_CategoryName,or_Qty,or_PhoneNumber,or_Location,p_image)){


                        builder.setTitle(" Order Form...")
                                .setMessage("New Oder Added Succesfully...")
                                .setIcon(R.drawable.baseline_add_task_24)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int i) {
                                        dialog.cancel();
                                    }
                                }).show();
                        Toast.makeText(U_OrderActivity.this, "Order Added ", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(U_OrderActivity.this, "Order Not Added ", Toast.LENGTH_SHORT).show();
                    }

                }




            }
        });






    }
}