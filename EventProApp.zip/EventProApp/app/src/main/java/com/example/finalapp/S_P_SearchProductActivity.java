package com.example.finalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class S_P_SearchProductActivity extends AppCompatActivity {


    EditText Search_productname;
    Button search_button,search_all_button;

    private ArrayList<ProductClass> ProductModelArrayList;
    private DBHandler dbHandler;
    private S_ProductRowViewHolder ProductRvAdapter;
    private RecyclerView SearchProductRV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sp_search_product);


        Search_productname=findViewById(R.id.s_search_product);
        search_button=findViewById(R.id.s_button_product);
        search_all_button=findViewById(R.id.s_button_allproduct);


        search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(Search_productname.getText().toString().isEmpty()){

                    Toast.makeText(S_P_SearchProductActivity.this, "Feild cant be blank!!!!", Toast.LENGTH_SHORT).show();

                }
                else {


                    ProductModelArrayList = new ArrayList<>();
                    dbHandler = new DBHandler(S_P_SearchProductActivity.this);

                    String SearchProduct = Search_productname.getText().toString();
                    ProductModelArrayList = dbHandler.SearchProduct2(SearchProduct);

                    ProductRvAdapter = new S_ProductRowViewHolder(ProductModelArrayList, S_P_SearchProductActivity.this);
                    SearchProductRV = findViewById(R.id.s_pro_rv02);

                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(S_P_SearchProductActivity.this, RecyclerView.VERTICAL, false);
                    SearchProductRV.setLayoutManager(linearLayoutManager);

                    SearchProductRV.setAdapter(ProductRvAdapter);

                    if (ProductModelArrayList.size() != 0) {

                        Toast.makeText(S_P_SearchProductActivity.this, "Product  Found", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(S_P_SearchProductActivity.this, "Product Not Found", Toast.LENGTH_SHORT).show();
                        Toast.makeText(S_P_SearchProductActivity.this, "Please Check correct Prodcut Name", Toast.LENGTH_SHORT).show();
                    }


                }



            }
        });

        search_all_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(S_P_SearchProductActivity.this,S_ViewAllProductActivity.class);
                startActivity(intent);


            }
        });



        String SPID = getIntent().getStringExtra("SPID");


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_Navigation);

        bottomNavigationView.setSelectedItemId(R.id.Search);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                if(menuItem.getItemId()== R.id.View){//S_P_CategoryProductActivity
                    Intent intent = new Intent(S_P_SearchProductActivity.this,S_P_CategoryProductActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                } else if (menuItem.getItemId()== R.id.Add) {//S_P_AddProductAvtivity
                    Intent intent = new Intent(S_P_SearchProductActivity.this,S_P_AddProductAvtivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);

                    overridePendingTransition(0,0);

                } else if (menuItem.getItemId()== R.id.Search) {
                    return  true;

                }
               else if (menuItem.getItemId()== R.id.Order) {//S_P_ViewOrderActivity
                    Intent intent = new Intent(S_P_SearchProductActivity.this,S_P_ViewOrderActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);

                    overridePendingTransition(0,0);
                }
                else if (menuItem.getItemId()== R.id.Query) {//S_P_ViewQueryActivity

                    Intent intent = new Intent(S_P_SearchProductActivity.this,S_P_ViewQueryActivity.class);
                    intent.putExtra("SPID",SPID);
                    startActivity(intent);

                    overridePendingTransition(0,0);
                }

                return false;
            }
        });



    }



}