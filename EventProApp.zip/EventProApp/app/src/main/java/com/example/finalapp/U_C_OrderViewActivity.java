package com.example.finalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class U_C_OrderViewActivity extends AppCompatActivity {


    private DBHandler dbHandler ;

    private ArrayList<OrderClass> OrderModelArrayList;
    private U_OrderRowViewHolder OrderRvAdapter;
    private RecyclerView SearchOrderRV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uc_order_view);
        dbHandler = new DBHandler(U_C_OrderViewActivity.this);

        String USID = getIntent().getStringExtra("USID");

        OrderModelArrayList = new ArrayList<>();

        OrderModelArrayList = dbHandler.SearchOder(USID);

        OrderRvAdapter = new U_OrderRowViewHolder(OrderModelArrayList, U_C_OrderViewActivity.this);
        SearchOrderRV = findViewById(R.id.or_rv);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(U_C_OrderViewActivity.this, RecyclerView.VERTICAL, false);
        SearchOrderRV.setLayoutManager(linearLayoutManager);

        SearchOrderRV.setAdapter(OrderRvAdapter);


        if (OrderModelArrayList.size() != 0) {

            Toast.makeText(U_C_OrderViewActivity.this, "Order  Found", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(U_C_OrderViewActivity.this, "Order Not Found", Toast.LENGTH_SHORT).show();
            Toast.makeText(U_C_OrderViewActivity.this, "Please Check your ID", Toast.LENGTH_SHORT).show();

        }


























        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_Navigation1);

        bottomNavigationView.setSelectedItemId(R.id.Order1);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                if(menuItem.getItemId()== R.id.View1){
                Intent intent = new Intent(U_C_OrderViewActivity.this,U_C_ViewQueryActivity.class);
                intent.putExtra("USID",USID);
                startActivity(intent);
                    overridePendingTransition(0,0);

                } else if (menuItem.getItemId()== R.id.Search1) {
                    Intent intent = new Intent(U_C_OrderViewActivity.this,U_C_ProductSearchActivity.class);
                    intent.putExtra("USID",USID);
                    startActivity(intent);

                    overridePendingTransition(0,0);
                } else if (menuItem.getItemId()== R.id.Query1) {
                    Intent intent = new Intent(U_C_OrderViewActivity.this, U_C_QueryActivity.class);
                    intent.putExtra("USID",USID);
                    startActivity(intent);
                    overridePendingTransition(0,0);
                }
                else if (menuItem.getItemId()== R.id.Order1) {
                    return  true;


                }
                return false;
            }
        });



    }


}