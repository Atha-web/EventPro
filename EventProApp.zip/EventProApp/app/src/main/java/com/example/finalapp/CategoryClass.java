package com.example.finalapp;

public class CategoryClass {

    String Category_ID;
    String Category_Name;
    int image;

    public CategoryClass(String category_ID, String category_Name, int image) {
        Category_ID = category_ID;
        Category_Name = category_Name;
        this.image = image;
    }

    public String getCategory_ID() {
        return Category_ID;
    }

    public void setCategory_ID(String category_ID) {
        Category_ID = category_ID;
    }

    public String getCategory_Name() {
        return Category_Name;
    }

    public void setCategory_Name(String category_Name) {
        Category_Name = category_Name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }



}
