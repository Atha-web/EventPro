package com.example.finalapp;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class S_ProductUpdateDeleteActivity extends AppCompatActivity {

   private EditText update_productname,update_price,update_qty,update_productdetails;
   private ImageView update_image,imagecamera,imagegallery;

   private Button Update_button,delete_button,back;
    AlertDialog.Builder builder;
   String u_productname,u_price,u_qty,u_productdetails,u_pid,SPID;
    private DBHandler dbHandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_update);


        dbHandler = new DBHandler(S_ProductUpdateDeleteActivity.this);
        builder = new AlertDialog.Builder(this);



        update_productname=findViewById(R.id.u_produtname);
        update_qty=findViewById(R.id.u_qty);
        update_price=findViewById(R.id.u_price);
        update_productdetails=findViewById(R.id.u_details);
        update_image=findViewById(R.id.u_image);
        Update_button=findViewById(R.id.buttonupdate);
        delete_button=findViewById(R.id.buttondelete);
        back=findViewById(R.id.buttonback13);


//After taking the details of recycling through intent, it is assigned to another variable using id.
        SPID=getIntent().getStringExtra("SPID");
        u_pid = getIntent().getStringExtra("Product_ID");
        u_productname = getIntent().getStringExtra("Product_Name");
        u_price = getIntent().getStringExtra("Product_Price");
        u_qty = getIntent().getStringExtra("Product_qty");
        u_productdetails = getIntent().getStringExtra("Product_Details");
        byte[] u_image = getIntent().getByteArrayExtra("Image");

        //that varible put into edittext and image view reprsesnet ids
        update_productname.setText(u_productname);
        update_price.setText(u_price);
        update_qty.setText(u_qty);
        update_productdetails.setText(u_productdetails);
        Bitmap bitmap = BitmapFactory.decodeByteArray(u_image,0,u_image.length);
        update_image.setImageBitmap(bitmap);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(S_ProductUpdateDeleteActivity.this, S_P_ProviderHomeAvtivtiy.class);
                i.putExtra("SPID",SPID);
                startActivity(i);
            }
        });


        Update_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(update_productname.getText().toString().isEmpty() ||update_qty.getText().toString().isEmpty() ||
                        update_price.getText().toString().isEmpty() || update_productdetails.getText().toString().isEmpty() ){
                    Toast.makeText(S_ProductUpdateDeleteActivity.this, "Feild cant be blank !!!", Toast.LENGTH_SHORT).show();

                }

                else{

                    if( dbHandler.UpdateProduct(u_pid, update_productname.getText().toString(), update_price.getText().toString()
                            ,update_qty.getText().toString(),update_productdetails.getText().toString(), u_image)){

                        builder.setTitle(" Product Update and Delete Form ...")
                                .setMessage("Product Updated Successfully ")
                                .setIcon(R.drawable.baseline_add_task_24)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int i) {
                                        dialog.cancel();
                                    }
                                }).show();
                        Toast.makeText(S_ProductUpdateDeleteActivity.this, "Updated.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(S_ProductUpdateDeleteActivity.this, " Not Updated.", Toast.LENGTH_SHORT).show();
                    }


                }



            }
        });


        delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               if(dbHandler.deleteProduct(u_pid)) {

                   builder.setTitle("Product Delete Form ...")
                           .setMessage("Product Deleted Succesfully... ")
                           .setIcon(R.drawable.baseline_add_task_24)
                           .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                               @Override
                               public void onClick(DialogInterface dialog, int i) {
                                   dialog.cancel();
                               }
                           }).show();
                   Toast.makeText(S_ProductUpdateDeleteActivity.this, "Deleted the Product", Toast.LENGTH_SHORT).show();

               }else{
                   Toast.makeText(S_ProductUpdateDeleteActivity.this, "Undeleted the Product", Toast.LENGTH_SHORT).show();

               }

            }
        });



        update_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChooseProfilePicture();
            }
        });




    }









    private void ChooseProfilePicture() {

        AlertDialog.Builder builder =
                new AlertDialog.Builder(S_ProductUpdateDeleteActivity.this);
        LayoutInflater inflater = getLayoutInflater();

        View dialogView =
                inflater.inflate(R.layout.alert_dialog_picture, null);
        builder.setCancelable(false);
        builder.setView(dialogView);

        imagecamera = dialogView.findViewById(R.id.imageViewDPPCamera);
        imagegallery = dialogView.findViewById(R.id.imageViewDPPGallery);
        final AlertDialog alertDialogProfilePicture = builder.create();
        alertDialogProfilePicture.show();

        imagecamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkAndRequestPermission()) {
                    takePictureFromCamera();
                    alertDialogProfilePicture.cancel();
                }
            }
        });

        imagegallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takePictureFromGallery();
                alertDialogProfilePicture.cancel();
            }
        });



    }

    private void takePictureFromCamera() {

        Intent takePicture=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(takePicture.resolveActivity(getPackageManager())!=null)
        {
            startActivityForResult(takePicture,2);
        }
    }

    private void takePictureFromGallery() {

        Intent pickPhoto=new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(pickPhoto,1);
    }

    private boolean checkAndRequestPermission() {
        if(Build.VERSION.SDK_INT>23)
        {
            int  cameraPermission=
                    ActivityCompat.checkSelfPermission
                            (S_ProductUpdateDeleteActivity.this,
                                    Manifest.permission.CAMERA);
            if(cameraPermission== PackageManager.PERMISSION_DENIED)
            {
                ActivityCompat.requestPermissions
                        (S_ProductUpdateDeleteActivity.this,new String[]
                                {Manifest.permission.CAMERA},20);
                return false;
            }
        }
        return true;
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode)
        {
            case 1:
                if(resultCode==RESULT_OK)
                {
                    Uri selectImageUri=data.getData();
                    update_image.setImageURI(selectImageUri);
                }
                break;
            case 2:
                if(resultCode==RESULT_OK)
                {
                    Bundle bundle=data.getExtras();
                    Bitmap bitmapImage=(Bitmap) bundle.get("data");
                    update_image.setImageBitmap(bitmapImage);
                }
                break;
        }

    }
}